// Serial Port app bootstrap: tabs, status bar (quick connect), STOP, shared log and command box.
import { $ } from './ui.js';
import { bus, state, supported, inToolBx, disconnect, lostIfPort, encodeCommand, send, sys } from './serial.js';
import { storage, migrateOldSettings } from './store.js';
import { initLog, setCompact, counters } from './log.js';
import { initTerminal, connectQuick, globalEnding, setBaud } from './terminal.js';
import { initControls, onProfileChange, stopAll, render as renderControls } from './controls.js';
import { initJoystick, setJoystickVisible } from './joystick.js';

let tab = 'terminal';

function showTab(name) {
  tab = name;
  document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.panel').forEach((p) => { p.hidden = p.dataset.panel !== name; });
  setCompact(name !== 'terminal');
  setJoystickVisible(name === 'joystick');
  if (name === 'controls') renderControls();
  storage.set('tab', name);
}

function onState(connected) {
  const b = $('statusBtn');
  b.classList.toggle('on', connected);
  b.textContent = connected ? '● Connected' : '○ Connect';
  b.title = connected ? 'Tap to disconnect' : 'Tap to connect (last device, or choose)';
  $('input').disabled = !connected; $('sendBtn').disabled = !connected;
  counters();
}

function sendCustom() {
  const v = $('input').value;
  if (!v) return;
  try {
    const asHex = $('hexSend').checked;
    const { bytes, label } = encodeCommand(asHex ? 'hex: ' + v : v, {}, asHex ? '' : globalEnding());
    if (send(bytes, label)) $('input').value = '';
  } catch (e) { sys(e.message); }
}

async function main() {
  await migrateOldSettings();
  $('where').textContent = inToolBx ? 'ToolBx' : (supported ? 'Browser' : 'No serial');
  $('where').title = 'Settings are saved in ' + storage.where;
  if (!supported) { $('unsupported').hidden = false; $('connectBtn').disabled = true; $('statusBtn').disabled = true; }

  initLog();
  await initTerminal();
  initJoystick();
  onProfileChange((p) => {
    $('stopBtn').hidden = !(p && p.stop);
    if (p && p.baud) setBaud(p.baud);
    if (tab === 'joystick') setJoystickVisible(true);
  });
  await initControls();

  bus.addEventListener('state', (e) => onState(e.detail.connected));
  onState(false);
  if (navigator.serial) navigator.serial.addEventListener('disconnect', (e) => lostIfPort(e.port));

  $('statusBtn').onclick = () => (state.connected ? disconnect() : connectQuick());
  $('stopBtn').onclick = () => { stopAll(); if (navigator.vibrate) navigator.vibrate(40); };
  $('sendBtn').onclick = sendCustom;
  $('input').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); sendCustom(); } });
  document.querySelectorAll('.tabs button').forEach((b) => { b.onclick = () => showTab(b.dataset.tab); });

  showTab(await storage.get('tab', 'terminal'));
  sys(supported ? `Ready. Settings are saved in ${storage.where}.` : 'Web Serial is not available here.');
}

main();
