// Controls tab: profiles of user-made buttons, toggles, sliders (servo bars), number inputs and status labels.
import { $, el, openSheet, field, textIn, numIn, selectIn, checkIn, colorIn, vibrate, downloadJson, pickJsonFile, uid } from './ui.js';
import { bus, sendCommand, sys } from './serial.js';
import { storage, saver } from './store.js';
import { globalEnding } from './terminal.js';

export const TYPES = {
  button: 'Button (momentary)',
  toggle: 'Toggle (on / off)',
  slider: 'Slider / servo bar',
  number: 'Number input',
  label: 'Status label (from replies)',
};

export const ENDINGS = [['inherit', 'Profile default'], ['', 'None'], ['\n', 'LF'], ['\r', 'CR'], ['\r\n', 'CR+LF']];
const endingLabel = (v) => (ENDINGS.find(([k]) => k === v) || [v, v])[1];

export function defaultStick(n) {
  return {
    style: 'stick', mode: 'analog', cmd: n === 0 ? 'J {x} {y}' : 'K {x} {y}', min: -100, max: 100,
    deadzone: 10, expo: 0, invertX: false, invertY: false, rateHz: 20, keepAliveMs: 0,
    release: 'center', centerCmd: '', ending: 'inherit',
    dirCmds: { F: 'F', B: 'B', L: 'L', R: 'R', FL: 'FL', FR: 'FR', BL: 'BL', BR: 'BR', C: 'S' },
  };
}

export function defaultJoystick() {
  return { layout: 'one', sticks: [defaultStick(0), defaultStick(1)], buttons: [], gamepad: true };
}

const newProfile = (name) => ({ id: uid(), name, baud: null, ending: '\n', stop: '', controls: [], joystick: defaultJoystick() });

let data = { active: null, list: [] };
let editing = false;
const save = saver('profiles', 300);
const listeners = new Set();

export const activeProfile = () => data.list.find((p) => p.id === data.active) || data.list[0];
export const onProfileChange = (cb) => listeners.add(cb);
export const persist = () => save(data);
const changed = () => { persist(); listeners.forEach((cb) => cb(activeProfile())); };

export function endingFor(ending) {
  const p = activeProfile();
  if (ending === undefined || ending === 'inherit') return p && p.ending !== undefined ? p.ending : globalEnding();
  return ending;
}

// ---------- sending helpers ----------
function sendCtrl(c, template, vars = {}, opts) {
  if (!template) return false;
  return sendCommand(template, { label: c.label, ...vars }, endingFor(c.ending), opts);
}

export function stopAll() {
  const p = activeProfile();
  if (p && p.stop) sendCommand(p.stop, {}, endingFor('inherit'), { priority: true });
}

// ---------- rendering ----------
function updateAll(id) {
  document.querySelectorAll(`[data-cid="${id}"]`).forEach((e) => e.update && e.update());
}

/** Builds one control tile. `edit` = {onEdit, onMove, onDup} in edit mode. */
export function buildControl(c, edit) {
  const tile = el('div', { class: `ctrl ${c.type}` + (c.size === '2' ? ' w2' : c.size === 'full' ? ' wfull' : '') + (edit ? ' edit' : '') + (c.vertical ? ' vertical' : ''),
    style: c.color ? `--c:${c.color}` : '' });
  tile.dataset.cid = c.id;
  const title = el('div', { class: 'ctrl-title' }, el('span', { text: c.label || TYPES[c.type] }));
  tile.append(title);

  if (edit) {
    tile.append(el('div', { class: 'edit-bar' },
      el('button', { text: '◀', title: 'Move earlier', onclick: (e) => { e.stopPropagation(); edit.onMove(-1); } }),
      el('button', { text: '▶', title: 'Move later', onclick: (e) => { e.stopPropagation(); edit.onMove(1); } }),
      el('button', { text: '⧉', title: 'Duplicate', onclick: (e) => { e.stopPropagation(); edit.onDup(); } }),
      el('button', { text: '✎', title: 'Edit', onclick: (e) => { e.stopPropagation(); edit.onEdit(); } }),
    ));
    tile.onclick = edit.onEdit;
    tile.append(el('div', { class: 'muted', text: summary(c) }));
    return tile;
  }

  if (c.type === 'button') {
    const b = el('button', { class: 'press', text: c.label || 'Send' });
    let repeat = null;
    const down = (e) => {
      e.preventDefault();
      try { b.setPointerCapture(e.pointerId); } catch (err) { }
      b.classList.add('down'); vibrate();
      sendCtrl(c, c.cmd);
      if (c.repeatMs > 0) repeat = setInterval(() => sendCtrl(c, c.cmd, {}, { key: 'rep:' + c.id }), c.repeatMs);
    };
    const up = () => {
      if (!b.classList.contains('down')) return;
      b.classList.remove('down');
      clearInterval(repeat); repeat = null;
      if (c.cmdRelease) sendCtrl(c, c.cmdRelease);
    };
    b.addEventListener('pointerdown', down);
    b.addEventListener('pointerup', up);
    b.addEventListener('pointercancel', up);
    b.oncontextmenu = (e) => e.preventDefault();
    tile.append(b);
  } else if (c.type === 'toggle') {
    const b = el('button', { class: 'press' });
    tile.update = () => {
      tile.classList.toggle('on', !!c.state);
      b.textContent = (c.state ? (c.onText || 'ON') : (c.offText || 'OFF'));
    };
    b.onclick = () => {
      const next = !c.state;
      if (sendCtrl(c, next ? c.cmdOn : c.cmdOff, { state: next ? 1 : 0 })) {
        c.state = next; vibrate(); persist(); updateAll(c.id);
      }
    };
    tile.update(); tile.append(b);
  } else if (c.type === 'slider') {
    const val = el('div', { class: 'val' });
    const r = el('input', { type: 'range', min: c.min, max: c.max, step: c.step || 1 });
    r.value = c.value ?? c.min;
    tile.update = () => { r.value = c.value; val.textContent = String(c.value); };
    let last = 0, trailing = null, sentValue = null;
    const push = () => {
      if (c.value === sentValue) return;
      last = Date.now(); sentValue = c.value;
      sendCtrl(c, c.cmd, { value: c.value }, { key: 'sl:' + c.id });
    };
    r.addEventListener('input', () => {
      c.value = Number(r.value); val.textContent = String(c.value);
      document.querySelectorAll(`[data-cid="${c.id}"]`).forEach((e) => { if (e !== tile && e.update) e.update(); });
      if (c.send !== 'release') {
        clearTimeout(trailing);
        const wait = 50 - (Date.now() - last);
        if (wait <= 0) push(); else trailing = setTimeout(push, wait);
      }
    });
    const release = () => {
      clearTimeout(trailing);
      if (c.returnTo !== '' && c.returnTo !== null && c.returnTo !== undefined && !isNaN(Number(c.returnTo))) {
        c.value = Number(c.returnTo); updateAll(c.id);
      }
      push(); persist();
    };
    r.addEventListener('change', release);
    tile.update(); tile.append(val, r);
  } else if (c.type === 'number') {
    const inp = el('input', { type: 'number', min: c.min, max: c.max, step: c.step || 1, value: c.value ?? '' });
    const go = () => {
      if (inp.value === '') return;
      c.value = Number(inp.value); persist();
      sendCtrl(c, c.cmd, { value: c.value });
    };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    tile.update = () => { inp.value = c.value ?? ''; };
    tile.append(el('div', { class: 'numrow' }, inp, el('button', { class: 'btn primary', text: 'Send', onclick: go })));
  } else if (c.type === 'label') {
    const v = el('div', { class: 'val' });
    tile.update = () => { v.textContent = (c.value ?? '–') + (c.unit ? ' ' + c.unit : ''); };
    tile.update(); tile.append(v);
  }
  return tile;
}

function summary(c) {
  switch (c.type) {
    case 'button': return `${c.cmd || '—'}${c.cmdRelease ? ' / ' + c.cmdRelease : ''}`;
    case 'toggle': return `${c.cmdOn || '—'} / ${c.cmdOff || '—'}`;
    case 'slider': return `${c.cmd || '—'}  (${c.min}–${c.max})`;
    case 'number': return c.cmd || '—';
    case 'label': return c.fb || 'no pattern';
    default: return '';
  }
}

export function render() {
  const p = activeProfile();
  const grid = $('ctrlGrid');
  grid.innerHTML = '';
  $('ctrlEmpty').hidden = p.controls.length > 0;
  $('addCtrlBtn').hidden = !editing;
  $('editBtn').textContent = editing ? '✓ Done' : '✎ Edit';
  p.controls.forEach((c, i) => {
    grid.append(buildControl(c, editing ? {
      onEdit: () => editControl(c),
      onMove: (d) => {
        const j = i + d;
        if (j < 0 || j >= p.controls.length) return;
        [p.controls[i], p.controls[j]] = [p.controls[j], p.controls[i]];
        changed(); render();
      },
      onDup: () => { p.controls.splice(i + 1, 0, { ...structuredClone(c), id: uid(), label: (c.label || '') + ' copy' }); changed(); render(); },
    } : null));
  });
  const sel = $('profileSel');
  sel.innerHTML = '';
  for (const pr of data.list) sel.append(el('option', { value: pr.id, text: pr.name, selected: pr.id === p.id }));
}

// ---------- editor ----------
function chooseType() {
  openSheet({
    title: 'Add control',
    okLabel: null,
    body: Object.entries(TYPES).map(([t, name]) => el('button', {
      type: 'button', class: 'btn', text: name, style: 'text-align:left',
      onclick: () => { document.getElementById('sheet').close(); editControl(null, t); },
    })),
  });
}

function editControl(c, newType) {
  const p = activeProfile();
  const isNew = !c;
  const type = c ? c.type : newType;
  const d = c || {
    id: uid(), type, label: '', color: '', size: '1', ending: 'inherit',
    cmd: type === 'slider' ? 'S1 {value}' : type === 'number' ? 'SET {value}' : '',
    cmdRelease: '', repeatMs: 0, cmdOn: '', cmdOff: '', onText: 'ON', offText: 'OFF',
    min: 0, max: type === 'slider' ? 180 : 255, step: 1, value: type === 'slider' ? 90 : 0,
    send: 'live', returnTo: '', vertical: false, fb: '', fbOn: '', fbOff: '', unit: '',
  };

  const label = textIn(d.label, 'Shown on the tile');
  const color = colorIn(d.color || '#0e7490');
  const size = selectIn([['1', 'Small'], ['2', 'Wide'], ['full', 'Full width']], d.size);
  const ending = selectIn(ENDINGS, d.ending ?? 'inherit');
  const body = [field('Name', label), el('div', { class: 'two' }, field('Colour', color), field('Size', size))];
  const tmplHint = 'Placeholders: {value} {state} {label}. Start with "hex:" for raw bytes, e.g. hex: A5 01 {value}';
  const f = {};

  if (type === 'button') {
    f.cmd = textIn(d.cmd, 'e.g. HORN 1'); f.cmdRelease = textIn(d.cmdRelease, 'optional, e.g. HORN 0');
    f.repeatMs = numIn(d.repeatMs || '', { min: 0, placeholder: '0 = off' });
    body.push(field('Command on press', f.cmd, tmplHint), field('Command on release', f.cmdRelease), field('Repeat while held (ms)', f.repeatMs, 'Resend the press command every N ms while held (motors).'));
  } else if (type === 'toggle') {
    f.cmdOn = textIn(d.cmdOn, 'e.g. LED ON'); f.cmdOff = textIn(d.cmdOff, 'e.g. LED OFF');
    f.onText = textIn(d.onText, 'ON'); f.offText = textIn(d.offText, 'OFF');
    f.fbOn = textIn(d.fbOn, 'e.g. LED:ON'); f.fbOff = textIn(d.fbOff, 'e.g. LED:OFF');
    body.push(field('Command for ON', f.cmdOn, tmplHint), field('Command for OFF', f.cmdOff),
      el('div', { class: 'two' }, field('Text when ON', f.onText), field('Text when OFF', f.offText)),
      el('h4', { text: 'Feedback (optional)' }),
      el('div', { class: 'two' }, field('Reply that means ON', f.fbOn), field('Reply that means OFF', f.fbOff)),
      el('div', { class: 'hint', text: 'Text or a regular expression matched against each received line; keeps the switch in sync with the board.' }));
  } else if (type === 'slider' || type === 'number') {
    f.cmd = textIn(d.cmd, 'e.g. S1 {value}');
    f.min = numIn(d.min); f.max = numIn(d.max); f.step = numIn(d.step, { min: 0, step: 'any' }); f.value = numIn(d.value);
    body.push(field('Command', f.cmd, tmplHint),
      el('div', { class: 'two' }, field('Min', f.min), field('Max', f.max)),
      el('div', { class: 'two' }, field('Step', f.step), field('Start value', f.value)));
    if (type === 'slider') {
      f.send = selectIn([['live', 'While dragging (every 50 ms)'], ['release', 'Only on release']], d.send);
      f.returnTo = numIn(d.returnTo, { placeholder: 'empty = stay' });
      f.vertical = checkIn('Vertical slider', d.vertical);
      f.fb = textIn(d.fb, 'e.g. S1=(\\d+)');
      body.push(field('Send', f.send), field('Return to value on release', f.returnTo, 'E.g. 90 to re-centre a servo.'), f.vertical,
        field('Feedback pattern (optional)', f.fb, 'Regular expression with one (group) for the value, e.g. S1=(\\d+)'));
    }
  } else if (type === 'label') {
    f.fb = textIn(d.fb, 'e.g. TEMP:(-?[\\d.]+)'); f.unit = textIn(d.unit, 'e.g. °C');
    body.push(field('Pattern', f.fb, 'Regular expression; the first (group) of a matching received line is shown.'), field('Unit', f.unit));
  }
  if (type !== 'label') body.push(field('Line ending', ending));

  openSheet({
    title: (isNew ? 'New ' : 'Edit ') + TYPES[type].toLowerCase(),
    body,
    extra: isNew ? [] : [{
      label: 'Delete', danger: true,
      onClick: (close) => {
        if (!confirm(`Delete "${d.label || TYPES[type]}"?`)) return;
        p.controls = p.controls.filter((x) => x.id !== d.id);
        p.joystick.buttons = p.joystick.buttons.filter((x) => x !== d.id);
        changed(); render(); close();
      },
    }],
    onOk: () => {
      d.label = label.value.trim();
      d.color = color.value; d.size = size.value; d.ending = ending.value;
      for (const [k, input] of Object.entries(f)) {
        if (input.input) d[k] = input.input.checked;
        else if (input.type === 'number') d[k] = input.value === '' ? (k === 'returnTo' ? '' : 0) : Number(input.value);
        else d[k] = input.value;
      }
      if (type === 'slider' || type === 'number') {
        if (d.max <= d.min) { alert('Max must be larger than Min'); return false; }
        d.value = Math.min(d.max, Math.max(d.min, d.value));
      }
      if (isNew) p.controls.push(d);
      changed(); render();
    },
  });
}

// ---------- profiles ----------
function profileMenu() {
  const p = activeProfile();
  const act = (label, fn, danger) => el('button', {
    type: 'button', class: 'btn' + (danger ? ' danger' : ''), text: label, style: 'text-align:left',
    onclick: () => { document.getElementById('sheet').close(); fn(); },
  });
  openSheet({
    title: `Profile: ${p.name}`,
    okLabel: null, cancelLabel: 'Close',
    body: [
      act('Profile settings (name, baud, line ending, STOP)', profileSettings),
      act('New profile', () => {
        const name = prompt('Profile name', 'New profile');
        if (!name) return;
        const n = newProfile(name.trim());
        data.list.push(n); data.active = n.id; changed(); render();
      }),
      act('Duplicate profile', () => {
        const n = { ...structuredClone(p), id: uid(), name: p.name + ' copy' };
        data.list.push(n); data.active = n.id; changed(); render();
      }),
      act('Export profile (.json)', () => downloadJson(`serialport-${p.name.replace(/\W+/g, '-')}.json`, { serialportProfile: 1, profile: p })),
      act('Import profile (.json)', importProfile),
      act('Delete profile', () => {
        if (data.list.length === 1) { alert('Keep at least one profile.'); return; }
        if (!confirm(`Delete profile "${p.name}" and its controls?`)) return;
        data.list = data.list.filter((x) => x.id !== p.id); data.active = data.list[0].id; changed(); render();
      }, true),
    ],
  });
}

function profileSettings() {
  const p = activeProfile();
  const name = textIn(p.name);
  const baud = numIn(p.baud ?? '', { min: 1, placeholder: 'keep current' });
  const ending = selectIn(ENDINGS.filter(([k]) => k !== 'inherit'), p.ending ?? '\n');
  const stop = textIn(p.stop, 'e.g. STOP');
  openSheet({
    title: 'Profile settings',
    body: [
      field('Name', name),
      field('Baud rate for this profile', baud, 'Applied to the next connection when you switch to this profile.'),
      field('Default line ending', ending, 'Used by controls set to "Profile default".'),
      field('STOP command', stop, 'Shows a red STOP button at the top; it skips the queue. Leave empty to hide it.'),
    ],
    onOk: () => {
      p.name = name.value.trim() || p.name;
      p.baud = baud.value ? Number(baud.value) : null;
      p.ending = ending.value; p.stop = stop.value.trim();
      changed(); render();
    },
  });
}

async function importProfile() {
  const j = await pickJsonFile();
  if (!j) return;
  if (j.__error || !j.profile || !Array.isArray(j.profile.controls)) { alert('Not a Serial Port profile file.'); return; }
  const n = { ...newProfile('Imported'), ...j.profile, id: uid() };
  n.joystick = { ...defaultJoystick(), ...(j.profile.joystick || {}) };
  n.controls = n.controls.map((c) => ({ ...c, id: c.id || uid() }));
  data.list.push(n); data.active = n.id; changed(); render();
  sys(`Imported profile "${n.name}"`);
}

// ---------- feedback from received lines ----------
function test(pattern, line) {
  try { return new RegExp(pattern).test(line); } catch (e) { return line.includes(pattern); }
}
function capture(pattern, line) {
  try { const m = new RegExp(pattern).exec(line); return m ? (m[1] ?? m[0]) : null; } catch (e) { return null; }
}
function onLine(line) {
  const p = activeProfile();
  if (!p) return;
  let dirty = false;
  for (const c of p.controls) {
    if (c.type === 'toggle') {
      if (c.fbOn && test(c.fbOn, line) && !c.state) { c.state = true; dirty = true; updateAll(c.id); }
      else if (c.fbOff && test(c.fbOff, line) && c.state) { c.state = false; dirty = true; updateAll(c.id); }
    } else if ((c.type === 'slider' || c.type === 'label') && c.fb) {
      const v = capture(c.fb, line);
      if (v !== null) { c.value = c.type === 'slider' ? Number(v) : v; dirty = true; updateAll(c.id); }
    }
  }
  if (dirty) persist();
}

export async function initControls() {
  data = await storage.get('profiles', null);
  if (!data || !Array.isArray(data.list) || !data.list.length) {
    const p = newProfile('Default');
    data = { active: p.id, list: [p] };
  }
  for (const p of data.list) {
    p.joystick = { ...defaultJoystick(), ...(p.joystick || {}) };
    p.joystick.sticks = [0, 1].map((i) => ({ ...defaultStick(i), ...((p.joystick.sticks || [])[i] || {}) }));
  }
  $('editBtn').onclick = () => { editing = !editing; render(); };
  $('addCtrlBtn').onclick = chooseType;
  $('profileMenuBtn').onclick = profileMenu;
  $('profileSel').onchange = (e) => { data.active = e.target.value; editing = false; changed(); render(); };
  bus.addEventListener('line', (e) => onLine(e.detail));
  render();
  listeners.forEach((cb) => cb(activeProfile()));
}

export { endingLabel };
