// Joystick tab: one or two sticks (or D-pads), modes analog / 4-dir / 8-dir / tank mix / single axis,
// buttons taken from the Controls tab, and physical gamepad support (Gamepad API).
import { $, el, openSheet, field, textIn, numIn, selectIn, checkIn, vibrate } from './ui.js';
import { encodeCommand, send, sendCommand, state } from './serial.js';
import { activeProfile, buildControl, persist, endingFor, ENDINGS, TYPES } from './controls.js';

const MODES = [
  ['analog', 'Analog x / y'], ['tank', 'Tank mix (left / right motor)'], ['dir4', '4 directions'],
  ['dir8', '8 directions'], ['axisX', 'Only X (steering)'], ['axisY', 'Only Y (throttle)'],
];
const DIRS = ['F', 'B', 'L', 'R', 'FL', 'FR', 'BL', 'BR', 'C'];
const DIR_NAMES = { F: 'Forward', B: 'Back', L: 'Left', R: 'Right', FL: 'Fwd-left', FR: 'Fwd-right', BL: 'Back-left', BR: 'Back-right', C: 'Centre' };

let sticks = [];       // runtime per stick
let visible = false;
let padRaf = 0;
const padButtons = []; // previous pressed state per gamepad button

// ---------- maths ----------
const clamp = (v, a = -1, b = 1) => Math.max(a, Math.min(b, v));
function shape(cfg, x, y) {
  const dz = clamp((cfg.deadzone || 0) / 100, 0, 0.9);
  const mag = Math.hypot(x, y);
  if (mag < dz) return [0, 0];
  const k = (mag - dz) / (1 - dz) / mag;
  x *= k; y *= k;
  const e = clamp((cfg.expo || 0) / 100, 0, 1);
  const ex = (v) => (1 - e) * v + e * v * v * v;
  x = ex(x); y = ex(y);
  if (cfg.invertX) x = -x;
  if (cfg.invertY) y = -y;
  return [clamp(x), clamp(y)];
}
const scale = (cfg, v) => Math.round(cfg.min + ((v + 1) / 2) * (cfg.max - cfg.min));

function direction(x, y, eight) {
  if (Math.hypot(x, y) < 0.35) return 'C';
  const a = (Math.atan2(y, x) * 180) / Math.PI; // 0 = right, 90 = forward
  if (eight) {
    const sectors = ['R', 'FR', 'F', 'FL', 'L', 'BL', 'B', 'BR'];
    return sectors[(Math.round(a / 45) + 8) % 8];
  }
  if (a >= 45 && a < 135) return 'F';
  if (a >= -135 && a < -45) return 'B';
  return Math.abs(a) < 45 ? 'R' : 'L';
}

/** Command text for the stick's current position (null = nothing to send). */
function output(cfg, rawX, rawY) {
  const [x, y] = shape(cfg, rawX, rawY);
  const vars = { x: scale(cfg, x), y: scale(cfg, y) };
  let template = cfg.cmd;
  switch (cfg.mode) {
    case 'tank': vars.left = scale(cfg, clamp(y + x)); vars.right = scale(cfg, clamp(y - x)); break;
    case 'axisX': vars.value = vars.x; break;
    case 'axisY': vars.value = vars.y; break;
    case 'dir4': case 'dir8': {
      const d = direction(x, y, cfg.mode === 'dir8');
      vars.dir = d;
      template = (cfg.dirCmds || {})[d] ?? '';
      break;
    }
    default: break;
  }
  if (!template) return null;
  try { return encodeCommand(template, vars, endingFor(cfg.ending)); } catch (e) { return null; }
}

// ---------- stick runtime ----------
function makeStick(cfg, index) {
  const s = { cfg, index, x: 0, y: 0, active: false, source: null, lastLabel: null, lastAt: 0, timer: null, knob: null, readout: null, dpadButtons: [] };

  s.tick = () => {
    const out = output(cfg, s.x, s.y);
    if (!out) return;
    const now = Date.now();
    if (out.label !== s.lastLabel || (cfg.keepAliveMs > 0 && now - s.lastAt >= cfg.keepAliveMs)) {
      if (state.port) send(out.bytes, out.label, { key: 'stick' + index });
      s.lastLabel = out.label; s.lastAt = now;
      s.readout.textContent = out.label.trim() || '·';
    }
  };
  s.start = (source) => {
    s.active = true; s.source = source;
    if (!s.timer) s.timer = setInterval(s.tick, 1000 / clamp(cfg.rateHz || 20, 1, 60));
    s.tick();
  };
  s.release = () => {
    if (!s.active) return;
    s.active = false; s.source = null;
    clearInterval(s.timer); s.timer = null;
    if (cfg.release !== 'hold') {
      s.x = 0; s.y = 0; s.draw();
      if (cfg.centerCmd) {
        if (state.port) sendCommand(cfg.centerCmd, {}, endingFor(cfg.ending), { key: 'stick' + index });
        s.lastLabel = null; s.readout.textContent = cfg.centerCmd;
      } else s.tick();
    }
  };
  s.set = (x, y) => { s.x = clamp(x); s.y = clamp(y); s.draw(); };
  s.draw = () => {
    if (s.knob) {
      const r = s.knob.parentElement.clientWidth * 0.31;
      s.knob.style.transform = `translate(calc(-50% + ${s.x * r}px), calc(-50% + ${-s.y * r}px))`;
    }
    for (const b of s.dpadButtons) b.classList.toggle('down', s.active && b.dx === Math.sign(Math.round(s.x)) && b.dy === Math.sign(Math.round(s.y)) && (b.dx || b.dy));
  };
  return s;
}

function stickView(s) {
  const wrap = el('div', { class: 'stick' });
  s.readout = el('div', { class: 'readout', text: '·' });
  if (s.cfg.style === 'dpad') {
    const pad = el('div', { class: 'dpad' });
    const cells = [[-1, 1, '↖'], [0, 1, '▲'], [1, 1, '↗'], [-1, 0, '◀'], [0, 0, '■'], [1, 0, '▶'], [-1, -1, '↙'], [0, -1, '▼'], [1, -1, '↘']];
    const diag = s.cfg.mode !== 'dir4';
    for (const [dx, dy, t] of cells) {
      const b = el('button', { text: t, class: (!diag && dx && dy) ? 'blank' : '' });
      b.dx = dx; b.dy = dy;
      b.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        if (!dx && !dy) { s.active = true; s.release(); return; } // centre = stop
        try { b.setPointerCapture(e.pointerId); } catch (err) { }
        vibrate(10);
        const n = dx && dy ? Math.SQRT1_2 : 1;
        s.set(dx * n, dy * n); s.start('touch');
      });
      const up = () => { if (s.source === 'touch') s.release(); };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
      b.oncontextmenu = (e) => e.preventDefault();
      s.dpadButtons.push(b);
      pad.append(b);
    }
    wrap.append(pad, s.readout);
    return wrap;
  }
  const base = el('div', { class: 'base' });
  s.knob = el('div', { class: 'knob' });
  base.append(s.knob);
  let pid = null;
  const move = (e) => {
    const r = base.getBoundingClientRect();
    const rad = r.width / 2;
    let x = (e.clientX - (r.left + rad)) / (rad * 0.62);
    let y = -(e.clientY - (r.top + rad)) / (rad * 0.62);
    const m = Math.hypot(x, y);
    if (m > 1) { x /= m; y /= m; }
    s.set(x, y);
  };
  base.addEventListener('pointerdown', (e) => {
    if (pid !== null) return;
    e.preventDefault();
    pid = e.pointerId;
    try { base.setPointerCapture(pid); } catch (err) { }
    move(e); s.start('touch');
  });
  base.addEventListener('pointermove', (e) => { if (e.pointerId === pid) move(e); });
  const up = (e) => { if (e.pointerId !== pid) return; pid = null; s.release(); };
  base.addEventListener('pointerup', up);
  base.addEventListener('pointercancel', up);
  wrap.append(base, s.readout);
  return wrap;
}

export function releaseAll() { sticks.forEach((s) => s.release()); }

export function renderJoystick() {
  releaseAll();
  const p = activeProfile();
  const j = p.joystick;
  const area = $('joyArea');
  area.innerHTML = '';
  const count = j.layout === 'two' ? 2 : 1;
  sticks = j.sticks.slice(0, count).map((cfg, i) => makeStick(cfg, i));
  const views = sticks.map(stickView);
  const buttons = j.buttons.map((id) => p.controls.find((c) => c.id === id)).filter(Boolean);
  const btnBox = buttons.length ? el('div', { class: 'joy-buttons' }, ...buttons.map((c) => buildControl(c, null))) : null;
  if (count === 2) area.append(views[0], btnBox || '', views[1]);
  else area.append(views[0], btnBox || '');
  requestAnimationFrame(() => sticks.forEach((s) => s.draw()));
}

// ---------- gamepad ----------
function pressControl(c, down) {
  if (!c) return;
  const tile = document.querySelector(`#joyArea [data-cid="${c.id}"] .press`) || document.querySelector(`[data-cid="${c.id}"] .press`);
  if (c.type === 'button' && tile) {
    tile.dispatchEvent(new PointerEvent(down ? 'pointerdown' : 'pointerup', { bubbles: true, pointerId: 999 }));
  } else if (c.type === 'toggle' && down && tile) tile.click();
}

function pollPad() {
  padRaf = 0;
  if (!visible) return;
  const p = activeProfile();
  const pads = navigator.getGamepads ? Array.from(navigator.getGamepads()).filter(Boolean) : [];
  const gp = pads[0];
  $('padState').textContent = gp ? `🎮 ${gp.id.replace(/\(.*\)/, '').trim().slice(0, 40)}` : '';
  if (gp && p.joystick.gamepad) {
    sticks.forEach((s, i) => {
      if (s.source === 'touch') return;
      const ax = gp.axes[i * 2] || 0, ay = -(gp.axes[i * 2 + 1] || 0);
      if (Math.hypot(ax, ay) > 0.08) {
        s.set(ax, ay);
        if (!s.active) s.start('pad');
      } else if (s.source === 'pad') s.release();
    });
    const ids = p.joystick.buttons;
    gp.buttons.forEach((b, i) => {
      const was = padButtons[i] || false;
      if (b.pressed !== was && i < ids.length) pressControl(p.controls.find((c) => c.id === ids[i]), b.pressed);
      padButtons[i] = b.pressed;
    });
  }
  padRaf = requestAnimationFrame(pollPad);
}

export function setJoystickVisible(v) {
  visible = v;
  if (!v) { releaseAll(); cancelAnimationFrame(padRaf); padRaf = 0; return; }
  renderJoystick();
  if (!padRaf) padRaf = requestAnimationFrame(pollPad);
}

// ---------- settings ----------
function stickFields(cfg, n) {
  const f = {
    style: selectIn([['stick', 'Round stick'], ['dpad', 'D-pad buttons']], cfg.style),
    mode: selectIn(MODES, cfg.mode),
    cmd: textIn(cfg.cmd, 'e.g. J {x} {y}  or  M {left} {right}'),
    min: numIn(cfg.min), max: numIn(cfg.max),
    deadzone: numIn(cfg.deadzone, { min: 0, max: 90 }), expo: numIn(cfg.expo, { min: 0, max: 100 }),
    rateHz: numIn(cfg.rateHz, { min: 1, max: 60 }), keepAliveMs: numIn(cfg.keepAliveMs, { min: 0, placeholder: '0 = off' }),
    release: selectIn([['center', 'Spring back to centre'], ['hold', 'Hold last position']], cfg.release),
    centerCmd: textIn(cfg.centerCmd, 'optional, e.g. STOP'),
    ending: selectIn(ENDINGS, cfg.ending ?? 'inherit'),
    invertX: checkIn('Invert X', cfg.invertX), invertY: checkIn('Invert Y', cfg.invertY),
  };
  const dirs = {};
  for (const d of DIRS) dirs[d] = textIn((cfg.dirCmds || {})[d] ?? '', d);
  const nodes = [
    el('h4', { text: n === 0 ? 'Left / main stick' : 'Right stick' }),
    el('div', { class: 'two' }, field('Look', f.style), field('Mode', f.mode)),
    field('Command template', f.cmd, 'Analog: {x} {y}. Tank: {left} {right}. Single axis: {value}. Not used by direction modes.'),
    el('div', { class: 'two' }, field('Output min', f.min), field('Output max', f.max)),
    el('div', { class: 'two' }, field('Dead zone %', f.deadzone), field('Expo %', f.expo, 'Finer control near centre')),
    el('div', { class: 'two' }, field('Send rate (per second)', f.rateHz), field('Keep-alive resend (ms)', f.keepAliveMs, 'Resend unchanged value while held; pairs with a board watchdog')),
    el('div', { class: 'two' }, field('On release', f.release), field('Command on release', f.centerCmd)),
    el('div', { class: 'row' }, f.invertX, f.invertY),
    field('Line ending', f.ending),
    el('div', { class: 'hint', text: 'Direction modes send these commands:' }),
    el('div', { class: 'two' }, ...DIRS.map((d) => field(DIR_NAMES[d], dirs[d]))),
  ];
  const read = () => {
    const o = { ...cfg };
    for (const [k, inp] of Object.entries(f)) {
      if (inp.input) o[k] = inp.input.checked;
      else if (inp.type === 'number') o[k] = inp.value === '' ? 0 : Number(inp.value);
      else o[k] = inp.value;
    }
    o.dirCmds = {};
    for (const d of DIRS) o.dirCmds[d] = dirs[d].value;
    return o;
  };
  return { nodes, read };
}

function openSettings() {
  const p = activeProfile();
  const j = p.joystick;
  const layout = selectIn([['one', 'One stick'], ['two', 'Two sticks']], j.layout);
  const pad = checkIn('Use a connected gamepad (left stick, right stick, buttons in order)', j.gamepad);
  const s0 = stickFields(j.sticks[0], 0);
  const s1 = stickFields(j.sticks[1], 1);
  const eligible = p.controls.filter((c) => c.type === 'button' || c.type === 'toggle' || c.type === 'slider');
  const picks = eligible.map((c) => { const ch = checkIn(`${c.label || TYPES[c.type]}`, j.buttons.includes(c.id)); ch.cid = c.id; return ch; });
  openSheet({
    title: 'Joystick settings',
    body: [
      field('Layout', layout), pad,
      el('h4', { text: 'Buttons shown with the stick (from the Controls tab)' }),
      picks.length ? el('div', { class: 'row' }, ...picks) : el('div', { class: 'hint', text: 'Add buttons or toggles in the Controls tab first.' }),
      ...s0.nodes, ...s1.nodes,
    ],
    onOk: () => {
      const a = s0.read(), b = s1.read();
      for (const s of [a, b]) if (s.max === s.min) { alert('Output min and max must differ'); return false; }
      j.layout = layout.value; j.gamepad = pad.input.checked;
      j.sticks = [a, b];
      j.buttons = picks.filter((x) => x.input.checked).map((x) => x.cid);
      persist();
      renderJoystick();
    },
  });
}

export function initJoystick() {
  $('joySettingsBtn').onclick = openSettings;
  document.addEventListener('visibilitychange', () => { if (document.hidden) releaseAll(); });
  window.addEventListener('blur', releaseAll);
  window.addEventListener('gamepadconnected', () => { if (visible && !padRaf) padRaf = requestAnimationFrame(pollPad); });
}
