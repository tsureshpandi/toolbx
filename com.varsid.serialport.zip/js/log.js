// Shared log view: full height on the Terminal tab, a few lines (expandable) elsewhere.
import { $ } from './ui.js';
import { bus, state, hex } from './serial.js';

const logEl = () => $('log');
const pad = (n, w = 2) => String(n).padStart(w, '0');
const stamp = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`; };
const decoder = new TextDecoder();
let rxLine = null;

function scroll() { if ($('autoscroll').checked) logEl().scrollTop = logEl().scrollHeight; }

export function write(kind, text) {
  if (kind !== 'rx') rxLine = null;
  const line = document.createElement('div');
  line.className = kind;
  if ($('timeView').checked) { const t = document.createElement('span'); t.className = 't'; t.textContent = stamp() + ' '; line.append(t); }
  line.append(document.createTextNode(text));
  logEl().append(line);
  while (logEl().childNodes.length > 3000) logEl().firstChild.remove();
  scroll();
  return line;
}

export const sysLine = (msg) => write('sys', '· ' + msg);

function rx(u8) {
  if ($('hexView').checked) { write('rx', hex(u8)); return; }
  const parts = decoder.decode(u8, { stream: true }).split('\n');
  parts.forEach((part, i) => {
    if (!rxLine) rxLine = write('rx', '');
    rxLine.lastChild.textContent += part.replace(/\r/g, '');
    if (i < parts.length - 1) rxLine = null;
  });
  scroll();
}

export function counters() { $('counters').textContent = `RX ${state.rx} · TX ${state.tx}`; }

export function setCompact(compact) {
  $('term').classList.toggle('compact', compact);
  $('logToggle').textContent = compact ? '▸ Log' : '▾ Log';
  scroll();
}

export function initLog() {
  bus.addEventListener('bytes', (e) => { rx(e.detail); counters(); });
  bus.addEventListener('sent', (e) => {
    counters();
    if ($('echo').checked) write('tx', $('hexView').checked ? hex(e.detail.bytes) : e.detail.label);
  });
  bus.addEventListener('sys', (e) => sysLine(e.detail));
  $('logToggle').onclick = () => setCompact(!$('term').classList.contains('compact'));
  $('hexView').addEventListener('change', () => { rxLine = null; });
  $('clearLog').onclick = () => { logEl().innerHTML = ''; rxLine = null; state.rx = state.tx = 0; counters(); };
  $('saveLog').onclick = () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([logEl().innerText], { type: 'text/plain' }));
    a.download = `serial-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.txt`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
}
