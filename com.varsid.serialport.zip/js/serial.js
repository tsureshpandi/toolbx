// Shared serial connection: open/close, read loop, line splitting, and one write queue for every tab.
// Events on `bus`: 'state' {connected}, 'bytes' Uint8Array, 'line' string, 'sent' {bytes, label}, 'sys' message.
import { storage } from './store.js';

export const bus = new EventTarget();
export const supported = !!navigator.serial;
export const inToolBx = !!(navigator.serial && navigator.serial.__toolbx);

export const state = { port: null, connected: false, rx: 0, tx: 0, options: null };

const emit = (type, detail) => bus.dispatchEvent(new CustomEvent(type, { detail }));
export const sys = (msg) => emit('sys', msg);

let reader = null, closing = false, loopDone = null;
const lineDecoder = new TextDecoder();
let lineBuf = '';

export function hex(u8) {
  return Array.from(u8, (b) => b.toString(16).toUpperCase().padStart(2, '0')).join(' ');
}

export function describe(p) {
  const i = p.getInfo();
  const h = (n) => (n ?? 0).toString(16).toUpperCase().padStart(4, '0');
  const ids = i.usbVendorId != null ? `${h(i.usbVendorId)}:${h(i.usbProductId)}` : 'unknown IDs';
  return [i.productName, ids, i.driver, i.serialNumber ? 'SN ' + i.serialNumber : null,
    i.portIndex ? 'port ' + (i.portIndex + 1) : null].filter(Boolean).join(' · ');
}

const signature = (p) => {
  const i = p.getInfo();
  return { vid: i.usbVendorId ?? null, pid: i.usbProductId ?? null, sn: i.serialNumber ?? null, idx: i.portIndex ?? 0 };
};

export async function choosePort(vendorFilter) {
  const filters = vendorFilter ? [{ usbVendorId: vendorFilter }] : [];
  try {
    return await navigator.serial.requestPort({ filters });
  } catch (e) {
    if (!(e.name === 'NotFoundError' && /selected/i.test(e.message))) sys(e.message);
    return null;
  }
}

/** Reconnect to the last used device if it is remembered and plugged in; otherwise show the chooser. */
export async function quickConnect(options, vendorFilter) {
  const last = await storage.get('lastPort');
  if (last) {
    try {
      const ports = await navigator.serial.getPorts();
      const match = ports.find((p) => {
        const s = signature(p);
        return s.vid === last.vid && s.pid === last.pid && s.idx === last.idx && (!last.sn || !s.sn || s.sn === last.sn);
      });
      if (match) return connect(match, options);
    } catch (e) { /* fall through */ }
  }
  const p = await choosePort(vendorFilter);
  if (p) return connect(p, options);
  return false;
}

export async function connect(p, options) {
  if (state.port) await disconnect();
  try {
    await p.open(options);
  } catch (e) {
    sys('Open failed: ' + e.message);
    return false;
  }
  state.port = p; state.connected = true; state.options = options;
  lineBuf = '';
  storage.set('lastPort', signature(p));
  emit('state', { connected: true });
  sys(`Connected: ${describe(p)} @ ${options.baudRate} ${options.dataBits}${options.parity[0].toUpperCase()}${options.stopBits}, flow ${options.flowControl}`);
  loopDone = readLoop();
  return true;
}

async function readLoop() {
  let keep = true;
  while (state.port && state.port.readable && keep) {
    reader = state.port.readable.getReader();
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value && value.length) received(value);
      }
    } catch (e) {
      if (!closing) sys('Read stopped: ' + e.message);
      keep = false;
    } finally {
      try { reader.releaseLock(); } catch (e) { }
      reader = null;
    }
    if (closing) keep = false;
  }
  if (!closing && state.port) lost('Connection closed');
}

function received(u8) {
  state.rx += u8.length;
  emit('bytes', u8);
  lineBuf += lineDecoder.decode(u8, { stream: true });
  let i;
  while ((i = lineBuf.indexOf('\n')) >= 0) {
    emit('line', lineBuf.slice(0, i).replace(/\r$/, ''));
    lineBuf = lineBuf.slice(i + 1);
  }
  if (lineBuf.length > 8192) lineBuf = lineBuf.slice(-4096);
}

export async function disconnect() {
  if (!state.port) return;
  closing = true;
  const p = state.port;
  queue.length = 0;
  try { if (reader) await reader.cancel(); } catch (e) { }
  try { await loopDone; } catch (e) { }
  try { await p.close(); } catch (e) { }
  state.port = null; state.connected = false; closing = false;
  emit('state', { connected: false });
  sys('Disconnected');
}

function lost(msg) {
  if (!state.port) return;
  const p = state.port;
  state.port = null; state.connected = false; queue.length = 0;
  try { p.close().catch(() => { }); } catch (e) { }
  emit('state', { connected: false });
  sys(msg);
}

export function lostIfPort(p) { if (p === state.port) lost('Device unplugged'); }

// ---------- commands & write queue ----------

function byteOf(v) {
  let n = Math.round(Number(v));
  if (!Number.isFinite(n)) n = 0;
  return ((n % 256) + 256) % 256; // negatives as two's complement
}

/**
 * Builds the bytes for a command template. Text: {name} placeholders are replaced, then the line ending is added.
 * "hex:" templates: space-separated hex bytes; {name} becomes one byte (0-255, negatives as two's complement).
 */
export function encodeCommand(template, vars = {}, ending = '\n') {
  const t = String(template ?? '');
  if (/^\s*hex:/i.test(t)) {
    const body = t.replace(/^\s*hex:/i, '').replace(/\{(\w+)\}/g, (_, k) => byteOf(vars[k]).toString(16));
    const parts = body.trim().split(/[\s,]+/).filter(Boolean);
    const out = new Uint8Array(parts.length);
    parts.forEach((h, i) => {
      const v = parseInt(h.replace(/^0x/i, ''), 16);
      if (isNaN(v) || v < 0 || v > 255) throw new Error(`"${h}" is not a hex byte`);
      out[i] = v;
    });
    return { bytes: out, label: hex(out) };
  }
  const text = t.replace(/\{(\w+)\}/g, (_, k) => (vars[k] === undefined ? '' : String(vars[k])));
  return { bytes: new TextEncoder().encode(text + (ending || '')), label: text };
}

const queue = []; // {bytes, label, key}
let pumping = false;

/**
 * Queue bytes for sending. `key`: a newer message with the same key replaces a waiting one (sliders, joysticks).
 * `priority`: clears the queue and goes first (STOP). Returns false when not connected.
 */
export function send(bytes, label, { key = null, priority = false } = {}) {
  if (!state.port) { sys('Not connected'); return false; }
  const item = { bytes, label, key };
  if (priority) { queue.length = 0; queue.unshift(item); }
  else if (key && queue.some((q) => q.key === key)) queue[queue.findIndex((q) => q.key === key)] = item;
  else queue.push(item);
  pump();
  return true;
}

export function sendCommand(template, vars, ending, opts) {
  try {
    const { bytes, label } = encodeCommand(template, vars, ending);
    if (!bytes.length) return false;
    return send(bytes, label, opts);
  } catch (e) {
    sys(e.message);
    return false;
  }
}

async function pump() {
  if (pumping) return;
  pumping = true;
  while (queue.length && state.port && state.port.writable) {
    const item = queue.shift();
    let w;
    try {
      w = state.port.writable.getWriter();
      await w.write(item.bytes);
      state.tx += item.bytes.length;
      emit('sent', item);
    } catch (e) {
      sys('Write failed: ' + e.message);
    } finally {
      try { w && w.releaseLock(); } catch (e) { }
    }
  }
  pumping = false;
}

// ---------- signals ----------
export async function setSignals(sig) {
  if (!state.port) return;
  try { await state.port.setSignals(sig); } catch (e) { sys('Signal: ' + e.message); }
}
