// Storage: inside ToolBx -> toolbx.store (ToolBx common database, included in ToolBx backups);
// as a plain web page -> localStorage. Same async API either way.
const PREFIX = 'serialport.';
const native = !!(window.toolbx && window.toolbx.store);

export const storage = {
  native,
  where: native ? 'ToolBx store' : 'browser storage',

  async get(key, fallback) {
    try {
      if (native) {
        const v = await window.toolbx.store.get(key);
        return v === undefined ? fallback : v;
      }
      const raw = localStorage.getItem(PREFIX + key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (e) {
      return fallback;
    }
  },

  async set(key, value) {
    try {
      if (native) await window.toolbx.store.set(key, value);
      else localStorage.setItem(PREFIX + key, JSON.stringify(value));
    } catch (e) {
      console.warn('storage.set failed', key, e);
    }
  },
};

// Debounced saver so sliders / typing do not write on every change.
export function saver(key, delay = 400) {
  let t = null, last;
  return (value) => {
    last = value;
    clearTimeout(t);
    t = setTimeout(() => storage.set(key, last), delay);
  };
}

/** One-time move of the old single-file version's settings (localStorage) into the ToolBx store. */
export async function migrateOldSettings() {
  try {
    const old = localStorage.getItem('serialport.settings.v1');
    if (!old) return;
    const s = JSON.parse(old);
    if (native) {
      if ((await storage.get('settings')) === undefined) {
        const { macros, ...rest } = s;
        await storage.set('settings', rest);
        if (macros) await storage.set('macros', macros);
      }
    } else if (localStorage.getItem(PREFIX + 'settings') === null) {
      const { macros, ...rest } = s;
      localStorage.setItem(PREFIX + 'settings', JSON.stringify(rest));
      if (macros) localStorage.setItem(PREFIX + 'macros', JSON.stringify(macros));
    }
    localStorage.removeItem('serialport.settings.v1');
  } catch (e) { /* ignore */ }
}
