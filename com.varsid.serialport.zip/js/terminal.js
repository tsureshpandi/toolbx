// Terminal tab: connection settings, remembered ports, signals, adapter tools, macros.
import { $, el, openSheet, field, textIn, checkIn } from './ui.js';
import { bus, state, inToolBx, describe, connect, disconnect, quickConnect, choosePort, setSignals, sys, sendCommand, encodeCommand, send } from './serial.js';
import { storage, saver } from './store.js';

const FIELDS = ['baud', 'dataBits', 'stopBits', 'parity', 'flow', 'bufferSize', 'vid', 'openDtr', 'openRts',
  'hexView', 'timeView', 'echo', 'autoscroll', 'ending', 'hexSend'];
const saveSettings = saver('settings');
let macros = [
  { label: 'Ctrl-C', text: '03', hex: true },
  { label: 'CR LF', text: '0D 0A', hex: true },
];
let pollTimer = null;

export function settingsSnapshot() {
  const s = {};
  for (const f of FIELDS) { const e = $(f); s[f] = e.type === 'checkbox' ? e.checked : e.value; }
  return s;
}
const persist = () => saveSettings(settingsSnapshot());

export function connectionOptions() {
  return {
    baudRate: parseInt($('baud').value, 10),
    dataBits: parseInt($('dataBits').value, 10),
    stopBits: parseFloat($('stopBits').value),
    parity: $('parity').value,
    flowControl: $('flow').value,
    bufferSize: Math.max(1, parseInt($('bufferSize').value, 10) || 4096),
    dtr: $('openDtr').checked, // ToolBx extras; desktop Chrome ignores them
    rts: $('openRts').checked,
  };
}

export function vendorFilter() {
  const v = $('vid').value.trim();
  return v ? parseInt(v.replace(/^0x/i, ''), 16) || null : null;
}

/** Profiles may carry a baud rate; applied to the next connection. */
export function setBaud(b) {
  if (!b || state.connected) return;
  $('baud').value = b; persist();
}

export function globalEnding() {
  return $('ending').value.replace(/\\n/g, '\n').replace(/\\r/g, '\r');
}

function validOptions() {
  const o = connectionOptions();
  if (!Number.isInteger(o.baudRate) || o.baudRate <= 0) { sys('Enter a valid baud rate'); return null; }
  return o;
}

export async function connectQuick() {
  const o = validOptions(); if (!o) return;
  persist();
  await quickConnect(o, vendorFilter());
}

async function connectChoose(p) {
  const o = validOptions(); if (!o) return;
  persist();
  p = p || await choosePort(vendorFilter());
  if (p) await connect(p, o);
}

function onState(connected) {
  for (const id of ['disconnectBtn', 'dtr', 'rts', 'breakBtn', 'resetBtn']) $(id).disabled = !connected;
  $('forgetBtn').disabled = !connected || !(state.port && state.port.forget);
  $('connectBtn').textContent = connected ? 'Switch port' : 'Choose port & connect';
  $('androidTools').hidden = !(connected && state.port && state.port.android);
  for (const id of ['baud', 'dataBits', 'stopBits', 'parity', 'flow', 'bufferSize']) $(id).disabled = connected;
  $('info').textContent = connected ? describe(state.port) : '';
  if (connected) {
    $('dtr').checked = $('openDtr').checked; $('rts').checked = $('openRts').checked;
    pollSignals();
  } else {
    clearTimeout(pollTimer);
    for (const l of ['cts', 'dsr', 'dcd', 'ri']) $(l).classList.remove('on');
  }
  refreshPorts();
}

async function refreshPorts() {
  if (!navigator.serial) return;
  let list = [];
  try { list = await navigator.serial.getPorts(); } catch (e) { }
  const box = $('ports'); box.innerHTML = '';
  $('portsBox').hidden = list.length === 0;
  for (const p of list) {
    const b = el('button', { class: 'btn', text: p === state.port ? 'Connected' : 'Connect', onclick: () => connectChoose(p) });
    b.disabled = p === state.port;
    box.append(el('div', { class: 'port' }, el('span', { text: describe(p) }), b));
  }
}

async function pollSignals() {
  clearTimeout(pollTimer);
  if (!state.port) return;
  if ($('sigCard').open && !document.hidden) {
    try {
      const s = await state.port.getSignals();
      $('cts').classList.toggle('on', !!s.clearToSend);
      $('dsr').classList.toggle('on', !!s.dataSetReady);
      $('dcd').classList.toggle('on', !!s.dataCarrierDetect);
      $('ri').classList.toggle('on', !!s.ringIndicator);
    } catch (e) { /* adapter cannot report input lines */ }
  }
  pollTimer = setTimeout(pollSignals, 500);
}

// ---------- macros ----------
function renderMacros() {
  const box = $('macros'); box.innerHTML = '';
  macros.forEach((m, i) => {
    const b = el('button', { class: 'btn', text: m.label });
    b.onclick = () => sendCommand(m.hex ? 'hex: ' + m.text : m.text, {}, m.hex ? '' : globalEnding());
    b.oncontextmenu = (ev) => { ev.preventDefault(); editMacro(i); };
    let t = null;
    b.addEventListener('touchstart', () => { t = setTimeout(() => { t = null; editMacro(i); }, 600); }, { passive: true });
    b.addEventListener('touchend', (ev) => { if (t) clearTimeout(t); else ev.preventDefault(); });
    box.append(b);
  });
  box.append(el('button', { class: 'btn', text: '+ Macro', onclick: () => editMacro(-1) }));
}

function editMacro(i) {
  const m = i >= 0 ? macros[i] : { label: '', text: '', hex: false };
  const label = textIn(m.label, 'Button name');
  const text = textIn(m.text, 'Command, e.g. status');
  const isHex = checkIn('Hex bytes (e.g. 0D 0A)', m.hex);
  openSheet({
    title: i >= 0 ? 'Edit macro' : 'New macro',
    body: [field('Name', label), field('Command', text, 'Sent with the line ending chosen next to Send (not for hex).'), isHex],
    extra: i >= 0 ? [{ label: 'Delete', danger: true, onClick: (close) => { macros.splice(i, 1); storage.set('macros', macros); renderMacros(); close(); } }] : [],
    onOk: () => {
      if (!label.value.trim()) return false;
      const v = { label: label.value.trim(), text: text.value, hex: isHex.input.checked };
      if (i >= 0) macros[i] = v; else macros.push(v);
      storage.set('macros', macros); renderMacros();
    },
  });
}

export async function initTerminal() {
  const s = await storage.get('settings', {});
  for (const f of FIELDS) if (f in s) { const e = $(f); if (e.type === 'checkbox') e.checked = s[f]; else e.value = s[f]; }
  macros = await storage.get('macros', macros);
  renderMacros();

  if (!inToolBx) {
    document.querySelectorAll('option.ext').forEach((o) => o.remove());
    $('extNote').textContent = 'DTR/RTS at open are ToolBx options; desktop browsers always raise them.';
  }
  for (const f of FIELDS) $(f).addEventListener('change', persist);

  $('connectBtn').onclick = () => connectChoose();
  $('disconnectBtn').onclick = disconnect;
  $('forgetBtn').onclick = async () => {
    const p = state.port; if (!p || !p.forget) return;
    await disconnect();
    try { await p.forget(); sys('Port forgotten'); storage.set('lastPort', null); } catch (e) { sys(e.message); }
    refreshPorts();
  };
  $('dtr').onchange = (e) => setSignals({ dataTerminalReady: e.target.checked });
  $('rts').onchange = (e) => setSignals({ requestToSend: e.target.checked });
  $('breakBtn').onclick = async () => {
    if (state.port && state.port.android) { try { await state.port.android.sendBreak(250); sys('Break sent'); } catch (e) { sys(e.message); } return; }
    await setSignals({ break: true }); setTimeout(() => setSignals({ break: false }), 250); sys('Break sent');
  };
  $('resetBtn').onclick = async () => {
    await setSignals({ dataTerminalReady: false, requestToSend: true });
    setTimeout(async () => {
      await setSignals({ dataTerminalReady: true, requestToSend: false });
      $('dtr').checked = true; $('rts').checked = false; sys('Reset pulse sent');
    }, 120);
  };
  $('purgeBtn').onclick = async () => { try { await state.port.android.purge(); sys('Buffers purged'); } catch (e) { sys(e.message); } };
  $('capsBtn').onclick = async () => {
    try {
      const c = await state.port.android.capabilities();
      sys(`${c.driver}: control lines [${c.controlLines.join(', ') || 'none'}], flow control [${c.flowControl.join(', ') || 'none'}]` + (c.latencyTimer ? ', latency timer' : ''));
    } catch (e) { sys(e.message); }
  };
  $('latencyBtn').onclick = async () => { try { await state.port.android.setLatency(parseInt($('latency').value, 10)); sys('Latency set'); } catch (e) { sys(e.message); } };
  $('sigCard').addEventListener('toggle', () => { if (state.port) pollSignals(); });

  bus.addEventListener('state', (e) => onState(e.detail.connected));
  if (navigator.serial) {
    navigator.serial.addEventListener('connect', (e) => { sys('Plugged in: ' + describe(e.port)); refreshPorts(); });
  }
  refreshPorts();
}

// Re-exported for app.js (custom command box).
export { encodeCommand, send };
