// Small DOM helpers and the settings sheet (a <dialog>).
export const $ = (id) => document.getElementById(id);

export function el(tag, props = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'style') e.style.cssText = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k in e && typeof v !== 'string') e[k] = v;
    else e.setAttribute(k, v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c.nodeType ? c : String(c));
  return e;
}

export const field = (label, input, hint) =>
  el('label', { class: 'f' }, label, input, hint ? el('span', { class: 'hint', text: hint }) : null);

export const textIn = (value = '', placeholder = '') => el('input', { type: 'text', value: value ?? '', placeholder, autocapitalize: 'off' });
export const numIn = (value, opts = {}) => el('input', { type: 'number', value: value ?? '', ...opts });
export const checkIn = (label, checked) => {
  const c = el('input', { type: 'checkbox' }); c.checked = !!checked;
  const l = el('label', { class: 'chk' }, c, ' ' + label);
  l.input = c;
  return l;
};
export function selectIn(options, value) {
  const s = el('select');
  for (const o of options) {
    const [v, t] = Array.isArray(o) ? o : [o, o];
    const opt = el('option', { value: v, text: t });
    if (String(v) === String(value)) opt.selected = true;
    s.append(opt);
  }
  return s;
}
export const colorIn = (value) => el('input', { type: 'color', value: value || '#0e7490', style: 'min-height:38px;width:100%;border-radius:8px' });

/**
 * Opens the shared sheet. `body`: array of nodes. `onOk` returns false to keep it open.
 * `extra`: [{label, danger, onClick}] buttons on the left.
 */
export function openSheet({ title, body, okLabel = 'Save', cancelLabel = 'Cancel', onOk, extra = [] }) {
  const dlg = $('sheet');
  const form = $('sheetForm');
  form.innerHTML = '';
  const close = () => dlg.close();
  const foot = el('div', { class: 'sheet-foot' },
    ...extra.map((b) => el('button', { type: 'button', class: 'btn' + (b.danger ? ' danger' : ''), text: b.label, onclick: () => b.onClick(close) })),
    el('span', { class: 'spacer' }),
    cancelLabel ? el('button', { type: 'button', class: 'btn', text: cancelLabel, onclick: close }) : null,
    okLabel ? el('button', {
      type: 'button', class: 'btn primary', text: okLabel,
      onclick: () => { if (!onOk || onOk() !== false) close(); },
    }) : null,
  );
  form.append(el('div', { class: 'sheet-head', text: title }), el('div', { class: 'sheet-body' }, ...body), foot);
  dlg.showModal();
  return close;
}

export function vibrate(ms = 15) {
  try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { }
}

export function downloadJson(name, data) {
  const a = el('a', { href: URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })), download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

export function pickJsonFile() {
  return new Promise((resolve) => {
    const inp = el('input', { type: 'file', accept: '.json,application/json' });
    inp.onchange = async () => {
      const f = inp.files && inp.files[0];
      if (!f) return resolve(null);
      try { resolve(JSON.parse(await f.text())); } catch (e) { resolve({ __error: e.message }); }
    };
    inp.click();
  });
}

export const uid = () => Math.random().toString(36).slice(2, 9);
