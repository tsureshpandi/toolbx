# Maths Worksheets

A free, offline, single-folder **random maths worksheet generator** for primary-school children.
Pick the kind of sheet, difficulty and layout, press **Print / Save PDF**, and get fresh A4 practice pages
(with an optional answer key) in **English or Tamil (தமிழ்)**.

* No server, no build step, no frameworks, no tracking – just `HTML + CSS + JS` (≈ 135 KB in total).
* Mobile first, works on desktop too, installable as an app (PWA) and usable offline.
* Designed for **printing on A4**: every worksheet is exactly one page, rows stretch to use the whole sheet.

It was modelled on Grade 1 workbook exercises (Goyal Brothers *Foundation Mathematics Book 1* style sheets) and later
extended to multiplication, division and 3–5 digit numbers.

---

## Features

| | |
|---|---|
| **Worksheet types** | Column Sums · Horizontal Sums · Long Division · Times Tables · Picture Add · Picture Subtract · Break-up Sums · Three-Number Sums · Missing Number · Tens & Ones · Word Problems · Number Order · Mental Maths · Speed Drill · Mixed Test |
| **Bundle tab** | Tick several worksheet types and print them all as **one PDF**, each on its own page |
| **Operations** | Addition, Subtraction, Add & Subtract, Multiplication, Division, Division with remainder, All four |
| **Difficulty** | Easy / Medium / Hard (controls carrying, borrowing, table range, number size) |
| **Digits** | 1–2 digit (Grade 1) or 3, 4, 5 digit addition & subtraction |
| **× ÷ range** | Tables up to 12 · 2–3 digit × 1 digit · 2–3 digit × 2 digit |
| **Layout** | Sums per row and rows per page on every tab (capped automatically to what fits) |
| **Copies** | 1–10 sheets of each worksheet type, set separately on every tab and for every entry in the Bundle – each copy has different numbers |
| **Paper** | Top / right / bottom / left margins in mm, optional Name & Date line, optional footer |
| **Answer key** | Compact key pages added at the end of the document |
| **Languages** | English and Tamil (UI, instructions, headings, word problems) – a Tamil font is embedded |
| **Repeatable** | A *sheet number* (seed): the same number always gives the same sheet; **New sheet** picks another. Every launch starts with a fresh number |
| **Remembers you** | Operation, difficulty, digits, ranges, language, Bundle ticks, per-sheet columns / rows / copies, margins and toggles are saved in the browser and restored next time |
| **Offline / PWA** | Installable on phones, tablets and desktops; works without internet after the first load |
| **Private** | Nothing is sent anywhere. Settings are kept in your browser's `localStorage` only (clear site data to reset) |

## Quick start

1. Download or clone this repository.
2. Open **`index.html`** in any modern browser (double-click works).
3. Choose a tab, set the options, press **🖨 Print / Save PDF**.
   In the print dialog choose **A4**, **margins: none/default** and (optional) turn off *Headers and footers*.

> Opening the file directly is fine for printing. To get the **Install app** button and offline support the
> page must be served over **HTTPS or `localhost`** (see below).

### Run locally as an installable app

```bash
cd maths-worksheets
python3 -m http.server 8080      # or: npx serve .
# open http://localhost:8080
```

### Host it for free (GitHub Pages)

1. Push the repository to GitHub.
2. **Settings → Pages → Deploy from a branch → `main` / root**.
3. Open `https://<your-user>.github.io/<repo>/` on your phone and use *Add to Home screen* / *Install*.

Any static host works (Netlify drop, Cloudflare Pages, an nginx folder …).

## Using the app

* **Tabs** – *Bundle* first, then one tab per worksheet type.
* **Options panel** (collapsible on phones, left side on desktop)
  * *Operation*, *Multiply/divide range* (shown for × and ÷), *Digits*, *Difficulty*
  * *Sums per row / Rows per page* – on a single tab as buttons + a dropdown, in the Bundle as small ↔ / ↕ dropdowns
    next to each ticked sheet. **Auto layout** resets them.
  * *Number of sheets* (1–10) for the current tab – in the Bundle every entry has its own 📄 dropdown
  * *Answer key* · *Name & Date line* · *Footer line*
  * *Paper margins (mm)* – Top, Right, Bottom, Left (0–25 mm)
  * *Sheet number* – type a number to reproduce an earlier sheet (this one is **not** remembered between launches, so you always get new sheets)
* **🎲 New sheet** – new random numbers, same settings.
* **🖨 Print / Save PDF** – opens the browser print dialog. The suggested PDF file name is
  `Worksheet_<date>_<difficulty>_<sheet number>`.

Greyed-out sheets in the Bundle do not support the chosen operation (for example *Picture Add* when *Subtraction*
is selected). The small symbols (`+ − × ÷`) on each entry show which operations it supports.

### Shareable / debug links

Settings can be passed in the URL:

```
index.html?tab=words&lang=ta&op=all&mdl=x1&diff=medium&seed=42&pages=2&cols=2&rows=8
```

`tab` (`bundle` or a type id), `lang` (`en`/`ta`), `op` (`add sub both mul div divr all`), `mdl` (`tables x1 x2`),
`dg` (`2–5`), `diff` (`easy medium hard`), `seed`, `pages` (number of sheets, 1–10; for the given `tab`, or every type when `tab` is `bundle`/absent) and `cols`/`rows` (applied to the given `tab`).

## Printing tips

* Use **A4**, scale **100 % / "Actual size"**, margins **None/Default** (the page already contains its own margins).
* Chrome / Edge: *More settings → untick "Headers and footers"* so the browser's own header does not appear.
* Android Chrome: *Print → Save as PDF*, paper size **A4**. iOS Safari: *Share → Print*, pinch-zoom the preview to get
  a PDF.
* Picture sheets use **emoji**; their look depends on the device's emoji font. They print fine in grey-scale.
* If a printer cuts the edges, increase the margins in *Paper margins*.

## Project layout

```
index.html              app shell (tabs, options panel, action bar)
style.css               app UI styles + the A4 sheet styles + print rules
app.js                  strings, number generators, worksheet types, layout engine, UI, self-test
fonts.css               embedded Tamil font subset (Noto Sans Tamil, base64 WOFF2)
sw.js                   service worker (offline cache)
manifest.webmanifest    PWA manifest
icons/                  app icons (SVG + 192/512 PNG)
docs/DEVELOPER.md       how the code works and how to extend it
```

## Developer notes (short)

* Everything is plain JavaScript – edit and refresh, nothing to compile.
* **Self-test:** open `index.html#selftest` (optionally `?n=4000#selftest`). It renders thousands of random settings
  and writes `OK <n>` or a list of clipped content into `<body data-overflow="…">` (view it via DevTools or
  `chrome --headless --dump-dom`).
* After changing any cached file, bump `VERSION` in `sw.js` so installed copies update.

See **[docs/DEVELOPER.md](docs/DEVELOPER.md)** for architecture, data flow, and step-by-step recipes
(add a worksheet type, an operation, a language, change difficulty, etc.).

## Browser support

Current Chrome, Edge, Firefox and Safari (desktop and mobile). Needs CSS grid, `mm` units, `@page`, and
`localStorage` (the app still works if storage is blocked – settings just are not remembered).

## Credits & licence

* Tamil text is set in **Noto Sans Tamil** (SIL Open Font License), subset and embedded in `fonts.css`.
* Worksheet formats are inspired by common primary-school workbooks; **no workbook content is included**.
* Add a `LICENSE` file of your choice (for example MIT) before publishing.
