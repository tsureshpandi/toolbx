'use strict';
/* Maths Worksheets – standalone generator (no libraries).
   Layout: i18n strings → number generators → item builders → worksheet types → document → UI. */
(() => {

/* ============================================================ helpers */
const $ = s => document.querySelector(s);
const hash = str => { let h = 2166136261; for (const ch of str) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; };
function RNG(seed) {                                   // mulberry32 – same seed, same sheet
  let a = seed >>> 0;
  const next = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const int = (lo, hi) => lo + Math.floor(next() * (hi - lo + 1));
  const pick = arr => arr[Math.floor(next() * arr.length)];
  const shuffle = arr => { const x = arr.slice(); for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(next() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; };
  return { next, int, pick, shuffle };
}
const BX = '<i class="bx"></i>';
const LN = '<i class="ln"></i>';
const uniq = (n, fn) => {                              // n items, avoiding duplicate keys
  const seen = new Set(), out = []; let dup = 0;
  while (out.length < n) { const it = fn(out.length); if (seen.has(it.k) && dup++ < 80) continue; seen.add(it.k); out.push(it); }
  return out;
};

/* ============================================================ strings (EN / TA) */
const S = {
  en: {
    appTitle: 'Maths Worksheets', bundle: 'Bundle', options: 'Options', language: 'Language',
    operation: 'Operation', add: 'Addition', sub: 'Subtraction', both: 'Add & Subtract', mul: 'Multiplication', div: 'Division', divr: 'Division with remainder', all: 'All four',
    mdl: 'Multiply / divide range', mdl_tables: 'Tables (up to 12)', mdl_x1: '2–3 digit × 1 digit', mdl_x2: '2–3 digit × 2 digit',
    digits: 'Digits (for + and −)', dg_2: '1–2 (Grade 1)', onlyFor: p => `Uses ${p.n} only.`,
    i_prod: 'Find the product :', i_quot: 'Divide :', i_divr: 'Divide and find the remainder :', i_all: 'Solve :',
    i_tables: 'Complete the tables :', tableOf: p => `Table of ${p.n}`, divBy: p => `Divide by ${p.n}`,
    difficulty: 'Difficulty', easy: 'Easy', medium: 'Medium', hard: 'Hard',
    pages: 'Pages per worksheet type', answerKey: 'Answer key (last pages)', header: 'Name & Date line',
    seed: 'Sheet number', seedHint: 'Same number = same sheet. “New sheet” picks a fresh one.',
    newSheet: '🎲 New sheet', print: '🖨 Print / Save PDF', install: 'Install app',
    all: 'All', none: 'None', typesTitle: 'Worksheets in this bundle',
    name: 'Name', date: 'Date', score: 'Score', time: 'Time', answer: 'Answer', keyTitle: 'Answer Key',
    page: 'Page', worksheet: 'Worksheet', test: 'TEST', empty: 'Tick at least one worksheet type to see it here.',
    fixedAdd: 'This worksheet is addition only.', fixedSub: 'This worksheet is subtraction only.',
    fixedAny: 'Not affected by the Operation setting.',
    paper: 'Paper margins (mm)', mTop: 'Top', mRight: 'Right', mBottom: 'Bottom', mLeft: 'Left', reset: 'Reset',
    footer: 'Footer line', sheets: 'Number of sheets (max 10)', sheetsTip: 'Number of sheets', perRow: 'Sums per row', rowsPer: 'Rows per page', autoMax: n => `Auto (max ${n})`, autoLayout: 'Auto layout',
    i_sum: 'Find the sum :', i_diff: 'Find the difference :', i_mix: 'Add or subtract :', i_fill: 'Fill in the boxes :',
    i_count: 'Count and add :', i_cross: 'Count, cross out and subtract :', i_find: 'Find :',
    i_words: 'Solve the following word problems :', i_blanks: 'Fill in the blanks :', i_order: 'Arrange the numbers :',
    i_fast: 'Finish as fast as you can!',
    asc: 'Small → Big (ascending)', desc: 'Big → Small (descending)',
    andMake: p => `${p.a} and ${p.b} make`,
    sumOf: p => `Sum of ${p.a} and ${p.b} is`, diffOf: p => `Difference of ${p.a} and ${p.b} is`,
    t_column: 'Column Sums', t_horizontal: 'Horizontal Sums', t_picAdd: 'Picture Add', t_picSub: 'Picture Subtract',
    t_breakup: 'Break-up Sums', t_three: 'Three-Number Sums', t_missing: 'Missing Number', t_tens: 'Tens & Ones',
    t_words: 'Word Problems', t_order: 'Number Order', t_mental: 'Mental Maths', t_test: 'Mixed Test', t_drill: 'Speed Drill', t_longdiv: 'Long Division', t_tables: 'Times Tables',
  },
  ta: {
    appTitle: 'கணிதப் பயிற்சித் தாள்கள்', bundle: 'தொகுப்பு', options: 'தேர்வுகள்', language: 'மொழி',
    operation: 'செயல்', add: 'கூட்டல்', sub: 'கழித்தல்', both: 'கூட்டல் & கழித்தல்', mul: 'பெருக்கல்', div: 'வகுத்தல்', divr: 'மீதியுடன் வகுத்தல்', all: 'நான்கும்',
    mdl: 'பெருக்கல் / வகுத்தல் வரம்பு', mdl_tables: 'வாய்ப்பாடு (12 வரை)', mdl_x1: '2–3 இலக்கம் × 1 இலக்கம்', mdl_x2: '2–3 இலக்கம் × 2 இலக்கம்',
    digits: 'இலக்கங்கள் (+, − க்கு)', dg_2: '1–2 (வகுப்பு 1)', onlyFor: p => `${p.n} மட்டும்.`,
    i_prod: 'பெருக்கற்பலன் காண்க :', i_quot: 'வகுக்க :', i_divr: 'வகுத்து மீதி காண்க :', i_all: 'தீர்க்க :',
    i_tables: 'வாய்ப்பாடுகளை நிரப்புக :', tableOf: p => `${p.n} இன் வாய்ப்பாடு`, divBy: p => `${p.n} ஆல் வகுத்தல்`,
    difficulty: 'நிலை', easy: 'எளிது', medium: 'நடுத்தரம்', hard: 'கடினம்',
    pages: 'ஒவ்வொரு தாள் வகைக்கும் பக்கங்கள்', answerKey: 'விடைத் தாள் (கடைசிப் பக்கங்களில்)', header: 'பெயர் & தேதி வரி',
    seed: 'தாள் எண்', seedHint: 'அதே எண் = அதே தாள். “புதிய தாள்” புதிய எண்ணைத் தரும்.',
    newSheet: '🎲 புதிய தாள்', print: '🖨 அச்சிடு / PDF', install: 'செயலியை நிறுவு',
    all: 'அனைத்தும்', none: 'எதுவுமில்லை', typesTitle: 'இந்தத் தொகுப்பில் உள்ள தாள்கள்',
    name: 'பெயர்', date: 'தேதி', score: 'மதிப்பெண்', time: 'நேரம்', answer: 'விடை', keyTitle: 'விடைகள்',
    page: 'பக்கம்', worksheet: 'பயிற்சித் தாள்', test: 'தேர்வு', empty: 'குறைந்தது ஒரு தாள் வகையைத் தேர்ந்தெடுக்கவும்.',
    fixedAdd: 'இந்தத் தாள் கூட்டலுக்கு மட்டும்.', fixedSub: 'இந்தத் தாள் கழித்தலுக்கு மட்டும்.',
    fixedAny: '“செயல்” தேர்வு இதற்குப் பொருந்தாது.',
    paper: 'தாள் ஓரங்கள் (மி.மீ)', mTop: 'மேல்', mRight: 'வலது', mBottom: 'கீழ்', mLeft: 'இடது', reset: 'மீட்டமை',
    footer: 'அடிக்குறிப்பு', sheets: 'தாள்களின் எண்ணிக்கை (அதிகபட்சம் 10)', sheetsTip: 'தாள்களின் எண்ணிக்கை', perRow: 'ஒரு வரிசைக்கு கணக்குகள்', rowsPer: 'ஒரு பக்கத்தில் வரிசைகள்', autoMax: n => `தானியங்கி (அதிகபட்சம் ${n})`, autoLayout: 'தானியங்கி அமைப்பு',
    i_sum: 'கூட்டுக :', i_diff: 'வித்தியாசம் காண்க :', i_mix: 'கூட்டுக அல்லது கழிக்க :', i_fill: 'கட்டங்களை நிரப்புக :',
    i_count: 'எண்ணிக் கூட்டுக :', i_cross: 'எண்ணி, வெட்டிக் கழிக்க :', i_find: 'காண்க :',
    i_words: 'கீழ்க்காணும் கணக்குகளைத் தீர்க்க :', i_blanks: 'வெற்றிடங்களை நிரப்புக :', i_order: 'எண்களை வரிசைப்படுத்துக :',
    i_fast: 'முடிந்தவரை வேகமாகச் செய்க!',
    asc: 'சிறியது → பெரியது (ஏறுவரிசை)', desc: 'பெரியது → சிறியது (இறங்குவரிசை)',
    andMake: p => `${p.a} உடன் ${p.b} கூட்டினால்`,
    sumOf: p => `${p.a}, ${p.b} ஆகியவற்றின் கூடுதல்`, diffOf: p => `${p.a}, ${p.b} ஆகியவற்றின் வித்தியாசம்`,
    t_column: 'நெடுவரிசைக் கணக்குகள்', t_horizontal: 'வரிசைக் கணக்குகள்', t_picAdd: 'படக் கூட்டல்', t_picSub: 'படக் கழித்தல்',
    t_breakup: 'பிரித்துக் கூட்டுதல்', t_three: 'மூன்று எண் கணக்குகள்', t_missing: 'விடுபட்ட எண்', t_tens: 'பத்துகள் & ஒன்றுகள்',
    t_words: 'சொல் கணக்குகள்', t_order: 'எண் வரிசை', t_mental: 'மனக்கணக்கு', t_test: 'கலவைத் தேர்வு', t_drill: 'விரைவுப் பயிற்சி', t_longdiv: 'நீள் வகுத்தல்', t_tables: 'வாய்ப்பாடுகள்',
  },
};
const UNIT = {
  ten: { en: n => n == 1 ? 'ten' : 'tens', ta: n => n == 1 ? 'பத்து' : 'பத்துகள்' },
  one: { en: n => n == 1 ? 'one' : 'ones', ta: n => n == 1 ? 'ஒன்று' : 'ஒன்றுகள்' },
};
const LETTERS = { en: ['A', 'B', 'C', 'D', 'E', 'F'], ta: ['அ', 'ஆ', 'இ', 'ஈ', 'உ', 'ஊ'] };

/* word-problem vocabulary. `loc` = Tamil “with <name>” form (precomputed, so no grammar guessing). */
const NAMES = [
  { en: 'Anu', ta: 'அனு', loc: 'அனுவிடம்' }, { en: 'Ravi', ta: 'ரவி', loc: 'ரவியிடம்' },
  { en: 'Meena', ta: 'மீனா', loc: 'மீனாவிடம்' }, { en: 'Kumar', ta: 'குமார்', loc: 'குமாரிடம்' },
  { en: 'Priya', ta: 'பிரியா', loc: 'பிரியாவிடம்' }, { en: 'Arun', ta: 'அருண்', loc: 'அருணிடம்' },
  { en: 'Divya', ta: 'திவ்யா', loc: 'திவ்யாவிடம்' }, { en: 'Karthik', ta: 'கார்த்திக்', loc: 'கார்த்திக்கிடம்' },
  { en: 'Lakshmi', ta: 'லட்சுமி', loc: 'லட்சுமியிடம்' }, { en: 'Vijay', ta: 'விஜய்', loc: 'விஜயிடம்' },
];
const OBJ = [
  { en: 'pencils', ta: 'பென்சில்கள்' }, { en: 'stickers', ta: 'ஸ்டிக்கர்கள்' }, { en: 'marbles', ta: 'கோலிகள்' },
  { en: 'mangoes', ta: 'மாம்பழங்கள்' }, { en: 'balloons', ta: 'பலூன்கள்' }, { en: 'stamps', ta: 'தபால்தலைகள்' },
  { en: 'books', ta: 'புத்தகங்கள்' }, { en: 'flowers', ta: 'பூக்கள்' }, { en: 'toys', ta: 'பொம்மைகள்' },
  { en: 'chocolates', ta: 'சாக்லேட்டுகள்' }, { en: 'bananas', ta: 'வாழைப்பழங்கள்' }, { en: 'crayons', ta: 'க்ரேயான்கள்' },
];
const WT = {
  add: [
    { en: p => `${p.N} had ${p.a} ${p.O}. A friend gave ${p.b} more ${p.O}. How many ${p.O} does ${p.N} have now?`,
      ta: p => `${p.loc} ${p.a} ${p.O} இருந்தன. நண்பர் இன்னும் ${p.b} ${p.O} கொடுத்தார். இப்போது ${p.loc} எத்தனை ${p.O} உள்ளன?` },
    { en: p => `There are ${p.a} ${p.O} in a basket. ${p.b} more ${p.O} are put in. How many ${p.O} are in the basket now?`,
      ta: p => `ஒரு கூடையில் ${p.a} ${p.O} உள்ளன. இன்னும் ${p.b} ${p.O} போடப்பட்டன. இப்போது கூடையில் மொத்தம் எத்தனை ${p.O} உள்ளன?` },
    { en: p => `${p.N} has ${p.a} ${p.O}. ${p.N2} has ${p.b} ${p.O}. How many ${p.O} do they have together?`,
      ta: p => `${p.loc} ${p.a} ${p.O} உள்ளன. ${p.loc2} ${p.b} ${p.O} உள்ளன. இருவரிடமும் சேர்த்து மொத்தம் எத்தனை ${p.O} உள்ளன?` },
    { en: p => `There are ${p.a} boys and ${p.b} girls in a class. How many children are there in all?`,
      ta: p => `ஒரு வகுப்பில் ${p.a} சிறுவர்களும் ${p.b} சிறுமிகளும் உள்ளனர். மொத்தம் எத்தனை குழந்தைகள் உள்ளனர்?` },
  ],
  sub: [
    { en: p => `${p.N} had ${p.a} ${p.O}. ${p.b} of them were lost. How many ${p.O} are left?`,
      ta: p => `${p.loc} ${p.a} ${p.O} இருந்தன. அவற்றில் ${p.b} தொலைந்து போயின. இப்போது எத்தனை ${p.O} மீதம் உள்ளன?` },
    { en: p => `There are ${p.a} ${p.O} in a box. ${p.b} ${p.O} are taken out. How many ${p.O} are left in the box?`,
      ta: p => `ஒரு பெட்டியில் ${p.a} ${p.O} இருந்தன. அவற்றில் ${p.b} எடுக்கப்பட்டன. பெட்டியில் எத்தனை ${p.O} மீதம் உள்ளன?` },
    { en: p => `${p.N} had ${p.a} ${p.O}. ${p.b} ${p.O} were given to a friend. How many ${p.O} are left with ${p.N}?`,
      ta: p => `${p.loc} ${p.a} ${p.O} இருந்தன. அவற்றில் ${p.b} நண்பருக்குக் கொடுக்கப்பட்டன. இப்போது ${p.loc} எத்தனை ${p.O} உள்ளன?` },
    { en: p => `There are ${p.a} children in a class. ${p.b} of them went out to play. How many children are left in the class?`,
      ta: p => `ஒரு வகுப்பில் ${p.a} குழந்தைகள் இருந்தனர். அவர்களில் ${p.b} பேர் விளையாடச் சென்றனர். வகுப்பில் எத்தனை குழந்தைகள் உள்ளனர்?` },
  ],
  mul: [
    { en: p => `${p.N} has ${p.g} boxes. Each box has ${p.e} ${p.O}. How many ${p.O} are there in all?`,
      ta: p => `${p.loc} ${p.g} பெட்டிகள் உள்ளன. ஒவ்வொரு பெட்டியிலும் ${p.e} ${p.O} உள்ளன. மொத்தம் எத்தனை ${p.O} உள்ளன?` },
    { en: p => `There are ${p.g} rows. Each row has ${p.e} ${p.O}. How many ${p.O} are there altogether?`,
      ta: p => `${p.g} வரிசைகள் உள்ளன. ஒவ்வொரு வரிசையிலும் ${p.e} ${p.O} உள்ளன. மொத்தம் எத்தனை ${p.O} உள்ளன?` },
    { en: p => `One bag has ${p.e} ${p.O}. How many ${p.O} are there in ${p.g} bags?`,
      ta: p => `ஒரு பையில் ${p.e} ${p.O} உள்ளன. ${p.g} பைகளில் மொத்தம் எத்தனை ${p.O} இருக்கும்?` },
  ],
  div: [
    { en: p => `${p.N} has ${p.a} ${p.O}. ${p.N} shares them equally among ${p.b} friends. How many ${p.O} does each friend get?`,
      ta: p => `${p.loc} ${p.a} ${p.O} உள்ளன. அவற்றை ${p.b} நண்பர்களுக்குச் சமமாகப் பகிர்ந்தால், ஒவ்வொருவருக்கும் எத்தனை ${p.O} கிடைக்கும்?` },
    { en: p => `${p.a} ${p.O} are packed equally into ${p.b} boxes. How many ${p.O} are in each box?`,
      ta: p => `${p.a} ${p.O} ${p.b} பெட்டிகளில் சமமாக அடுக்கப்பட்டன. ஒவ்வொரு பெட்டியிலும் எத்தனை ${p.O} உள்ளன?` },
    { en: p => `There are ${p.a} ${p.O}. ${p.b} ${p.O} are put in each bag. How many bags are needed?`,
      ta: p => `${p.a} ${p.O} உள்ளன. ஒவ்வொரு பையிலும் ${p.b} ${p.O} வைத்தால், எத்தனை பைகள் தேவை?` },
  ],
  divr: [
    { en: p => `${p.a} ${p.O} are shared equally among ${p.b} children. How many does each child get? How many are left?`,
      ta: p => `${p.a} ${p.O} ${p.b} குழந்தைகளுக்குச் சமமாகப் பகிரப்பட்டன. ஒவ்வொருவருக்கும் எத்தனை கிடைக்கும்? மீதம் எத்தனை?` },
    { en: p => `${p.N} has ${p.a} ${p.O}. ${p.N} puts ${p.b} ${p.O} in each bag. How many full bags are made? How many ${p.O} are left?`,
      ta: p => `${p.loc} ${p.a} ${p.O} உள்ளன. ஒரு பையில் ${p.b} ${p.O} வீதம் வைத்தால், எத்தனை முழுப் பைகள் கிடைக்கும்? எத்தனை ${p.O} மீதம்?` },
  ],
};
const EMO = ['🍎', '🍌', '🍓', '🍊', '🌸', '⭐', '🐟', '🐦', '🎈', '⚽', '🚗', '🐱', '🦋', '🍪', '🐞', '🍇'];

/* ============================================================ number generators */
// difficulty: easy = within 10 · medium = within 20 / tens / no carry · hard = 2-digit with carry / borrow
function pAdd(r, d) {
  if (d === 'easy') { const s = r.int(2, 10), a = r.int(1, s - 1); return [a, s - a]; }
  if (d === 'medium') {
    const k = r.int(0, 2);
    if (k === 0) { const a = r.int(2, 9), b = r.int(Math.max(2, 11 - a), 9); return [a, b]; }
    if (k === 1) { const ta = r.int(1, 8), tb = r.int(1, 9 - ta); return [ta * 10, tb * 10]; }
    const ta = r.int(1, 8), tb = r.int(1, 9 - ta), oa = r.int(0, 8), ob = r.int(0, 9 - oa);
    return [ta * 10 + oa, tb * 10 + ob];
  }
  const oa = r.int(1, 9), ob = r.int(10 - oa, 9), ta = r.int(1, 7), tb = r.int(1, 8 - ta);
  return [ta * 10 + oa, tb * 10 + ob];                          // carries from ones to tens
}
function pSub(r, d) {
  if (d === 'easy') { const a = r.int(2, 10), b = r.int(1, a - 1); return [a, b]; }
  if (d === 'medium') {
    const k = r.int(0, 2);
    if (k === 0) { const a = r.int(11, 18), b = r.int(a - 9, 9); return [a, b]; }
    if (k === 1) { const ta = r.int(2, 9), tb = r.int(1, ta - 1); return [ta * 10, tb * 10]; }
    const ta = r.int(2, 9), tb = r.int(1, ta), oa = r.int(1, 9), ob = r.int(0, oa);
    const a = ta * 10 + oa; let b = tb * 10 + ob; if (b === a) b = a - 1; return [a, b];
  }
  const oa = r.int(0, 8), ob = r.int(oa + 1, 9), ta = r.int(2, 9), tb = r.int(1, ta - 1);
  return [ta * 10 + oa, tb * 10 + ob];                          // borrows from tens
}
const dnum = ds => ds.reduce((n, x) => n * 10 + x, 0);
function pAddN(r, d, D) {                                       // D-digit + D-digit, digit by digit (no carry / some / many)
  const A = [], B = [];
  for (let i = 0; i < D; i++) {
    const carry = i > 0 && (d === 'hard' || (d === 'medium' && r.next() < .5)); let x, y;
    if (i === 0) { x = r.int(1, 7); y = r.int(1, 8 - x); }       // leading digit never overflows
    else if (carry) { x = r.int(1, 9); y = r.int(10 - x, 9); }
    else { x = r.int(0, 9); y = r.int(0, 9 - x); }
    A.push(x); B.push(y);
  }
  return [dnum(A), dnum(B)];
}
function pSubN(r, d, D) {                                       // D-digit − D-digit (no borrow / some / many)
  const A = [], B = [];
  for (let i = 0; i < D; i++) {
    const borrow = i > 0 && (d === 'hard' || (d === 'medium' && r.next() < .5)); let x, y;
    if (i === 0) { x = r.int(2, 9); y = r.int(1, x - 1); }
    else if (borrow) { x = r.int(0, 8); y = r.int(x + 1, 9); }
    else { x = r.int(0, 9); y = r.int(0, x); }
    A.push(x); B.push(y);
  }
  return [dnum(A), dnum(B)];
}
// × ÷ ranges: tables (to 12) · x1 = 2–3 digit by 1 digit · x2 = 2–3 digit by 2 digit
function pMul(r, d, m) {
  if (m === 'tables') { const hi = { easy: 5, medium: 10, hard: 12 }[d], a = r.int(2, hi), b = r.int(2, d === 'hard' ? 12 : 10); return r.next() < .5 ? [a, b] : [b, a]; }
  if (m === 'x1') { const [lo, hi] = { easy: [10, 49], medium: [20, 399], hard: [100, 999] }[d]; return [r.int(lo, hi), r.int(d === 'hard' ? 3 : 2, d === 'easy' ? 5 : 9)]; }
  const [lo, hi] = { easy: [11, 49], medium: [20, 399], hard: [100, 999] }[d], [bl, bh] = { easy: [11, 29], medium: [11, 59], hard: [12, 99] }[d];
  return [r.int(lo, hi), r.int(bl, bh)];
}
function divParts(r, d, m) {                                    // divisor b and quotient q
  if (m === 'tables') { const hi = { easy: 5, medium: 10, hard: 12 }[d]; return [r.int(2, hi), r.int(2, d === 'hard' ? 12 : 10)]; }
  const b = m === 'x1' ? r.int(d === 'hard' ? 3 : 2, d === 'easy' ? 5 : 9) : r.int(...{ easy: [11, 19], medium: [11, 59], hard: [12, 99] }[d]);
  const [lo, hi] = m === 'x1' ? { easy: [10, 99], medium: [20, 500], hard: [100, 999] }[d] : { easy: [110, 999], medium: [200, 2999], hard: [500, 9999] }[d];
  return [b, r.int(Math.max(2, Math.ceil(lo / b)), Math.floor(hi / b))];
}
const ansTxt = q => q.op === 'divr' ? `${q.ans} R ${q.rem}` : String(q.ans);
function Q(c) {                                                 // one random question from the sheet's allowed operations
  const { r } = c, op = r.pick(c.ops);
  if (op === 'add' || op === 'sub') {
    const [a, b] = c.dg > 2 ? (op === 'add' ? pAddN : pSubN)(r, c.diff, c.dg) : (op === 'add' ? pAdd : pSub)(r, c.diff);
    return { op, a, b, sym: op === 'add' ? '+' : '−', ans: op === 'add' ? a + b : a - b, rem: 0 };
  }
  if (op === 'mul') { const [a, b] = pMul(r, c.diff, c.mdl); return { op, a, b, sym: '×', ans: a * b, rem: 0 }; }
  const [b, q] = divParts(r, c.diff, c.mdl), rem = op === 'divr' ? r.int(1, b - 1) : 0;
  return { op, a: b * q + rem, b, sym: '÷', ans: q, rem };
}
const split = (r, s, n) => {                                     // s into n positive parts
  if (n === 2) { const a = r.int(1, s - 1); return [a, s - a]; }
  const a = r.int(1, s - 2), b = r.int(1, s - a - 1); return [a, b, s - a - b];
};

/* ============================================================ item builders → {h, a, k, cls} */
const unit = (c, n, u) => `${n} ${UNIT[u][c.lang](n)}`;
const word = (c, u, plural = true) => UNIT[u][c.lang](plural ? 2 : 1);

function itVert(c) {
  const q = Q(c), { a, b } = q, la = String(a).length, lb = String(b).length, mul = q.op === 'mul';
  const w = Math.max(la, lb), W = mul ? Math.max(w, la + lb) : w, wd = `style="width:${W * 6.5 + 6}mm"`;
  const dig = n => [...String(n).padStart(W, ' ')].map(ch => `<b>${ch === ' ' ? '&nbsp;' : ch}</b>`).join('');
  const head = W >= 2 && W <= 3 ? `<div class="to" ${wd}>${['H', 'T', 'O'].slice(3 - W).map(x => `<b>${x}</b>`).join('')}</div>` : '';
  const work = mul && lb > 1 ? `<div class="work" ${wd}><i></i><i></i></div>` : '';
  return { cls: 'vs', k: `${q.op}${a}_${b}`, a: String(q.ans),
    h: `${head}<div class="dr" ${wd}>${dig(a)}</div><div class="dr" ${wd}><u>${q.sym}</u>${dig(b)}</div><div class="rule" ${wd}></div>${work}<div class="abox" ${wd}></div>` };
}
function itHoriz(c) {
  const q = Q(c), rm = q.op === 'divr';
  return { cls: 'hs', k: `${q.op}${q.a}_${q.b}`, a: ansTxt(q), h: `<span>${q.a} ${q.sym} ${q.b} =</span>${BX}${rm ? `<span>R</span>${BX}` : ''}` };
}
function itLongDiv(c) {
  const q = Q(c), rm = q.op === 'divr';
  return { cls: 'ld', k: `${q.a}_${q.b}`, a: ansTxt(q),
    h: `<div class="qrow">${BX}${rm ? `<b>R</b>${BX}` : ''}</div><div class="brk"><span class="dv">${q.b}</span><span class="dd">${q.a}</span></div>` };
}
function itPicAdd(c) {
  const { r, diff } = c, cap = { easy: 10, medium: 14, hard: 18 }[diff];
  const a = r.int(1, Math.min(9, cap - 1)), b = r.int(1, Math.min(9, cap - a)), e = r.pick(EMO);
  const g = n => Array.from({ length: n }, () => `<span>${e}</span>`).join('');
  return { cls: 'pic', k: `${a}_${b}_${e}`, a: `${a} + ${b} = ${a + b}`,
    h: `<div class="pp"><div class="pg">${g(a)}</div><div class="sg">+</div><div class="pg">${g(b)}</div></div>` +
       `<div class="pt">${c.t('andMake', { a, b })} ${BX}</div><div class="pe">${a} + ${b} = ${BX}</div>` };
}
function itPicSub(c, i) {
  const { r, diff } = c, [lo, hi] = { easy: [3, 10], medium: [8, 14], hard: [10, 18] }[diff];
  const a = r.int(lo, hi), b = r.int(1, Math.min(a - 1, 9)), e = r.pick(EMO);
  const pics = Array.from({ length: a }, (_, j) => `<span${j < b ? ' class="x"' : ''}>${e}</span>`).join('');
  const eq = i % 2 ? `${BX} − ${BX} = ${BX}` : `${a} − ${b} = ${BX}`;
  return { cls: 'pic sub', k: `${a}_${b}_${e}`, a: `${a} − ${b} = ${a - b}`,
    h: `<div class="pp"><div class="pg">${pics}</div></div><div class="pe">${eq}</div>` };
}
function itBreak(c) {
  const { r, diff } = c; let a, b, d;
  if (diff === 'easy') { [a, b, d] = split(r, r.int(4, 10), 3); }
  else if (diff === 'medium') { do { a = r.int(2, 9); b = r.int(2, 9); d = r.int(1, 6); } while (!(a + b >= 10 && a + b + d <= 20)); }
  else { a = r.int(11, 49); b = r.int(2, 9); d = r.int(2, 9); }
  return { cls: 'bu', k: `${a}_${b}_${d}`, a: `${a + b} + ${d} = ${a + b + d}`,
    h: `<div><span class="bb">${a} + ${b}</span> + ${d}</div><div class="ar">↓</div><div>${BX} + ${BX} = ${BX}</div>` };
}
function itThree(c) {
  const { r, diff } = c, M = { easy: 10, medium: 20, hard: 99 }[diff];
  const pat = c.op === 'add' ? '++' : c.op === 'sub' ? '--' : r.pick(['++', '+-', '-+', '--']);   // c.op is 'mix' when both
  let a, b, d, ans;
  if (pat === '++') { [a, b, d] = split(r, r.int(4, M), 3); ans = a + b + d; }
  else if (pat === '--') { a = r.int(4, M); b = r.int(1, a - 2); d = r.int(1, a - b - 1); ans = a - b - d; }
  else if (pat === '+-') { const s = r.int(3, M); [a, b] = split(r, s, 2); d = r.int(1, s - 1); ans = s - d; }
  else { a = r.int(3, M - 1); b = r.int(1, a - 1); d = r.int(1, M - (a - b)); ans = a - b + d; }
  const sy = x => x === '+' ? '+' : '−';
  return { cls: 'hs', k: `${pat}${a}_${b}_${d}`, a: String(ans), h: `<span>${a} ${sy(pat[0])} ${b} ${sy(pat[1])} ${d} =</span>${BX}` };
}
function itMissing(c) {
  const mk = BX, { r } = c, q = Q(c), { a, b } = q, k = r.int(0, 3); let t, ans;
  if (q.op === 'add') {
    const s = a + b;
    [t, ans] = [[`${a} + ${b} = ${mk} + ${a}`, b], [`${a} + ${b} = ${b} + ${mk}`, a], [`${a} + ${mk} = ${s}`, b], [`${mk} + ${b} = ${s}`, a]][k];
  } else if (q.op === 'sub') {
    const d = a - b;
    [t, ans] = [[`${a} − ${mk} = ${d}`, b], [`${a} − ${mk} = ${d}`, b], [`${mk} − ${b} = ${d}`, a],
      r.next() < .5 ? [`${a} − 0 = ${mk}`, a] : [`${a} − ${a} = ${mk}`, 0]][k];
  } else if (q.op === 'mul') {
    [t, ans] = [[`${a} × ${mk} = ${a * b}`, b], [`${mk} × ${b} = ${a * b}`, a], [`${a} × ${b} = ${mk}`, a * b], [`${a} × ${mk} = ${a * b}`, b]][k];
  } else if (q.op === 'div') {
    [t, ans] = [[`${a} ÷ ${mk} = ${q.ans}`, b], [`${mk} ÷ ${b} = ${q.ans}`, a], [`${a} ÷ ${b} = ${mk}`, q.ans], [`${a} ÷ ${mk} = ${q.ans}`, b]][k];
  } else {
    [t, ans] = [[`${mk} ÷ ${b} = ${q.ans} R ${q.rem}`, a], [`${a} ÷ ${b} = ${q.ans} R ${mk}`, q.rem], [`${a} ÷ ${b} = ${mk} R ${q.rem}`, q.ans], [`${mk} ÷ ${b} = ${q.ans} R ${q.rem}`, a]][k];
  }
  return { cls: 'hs', k: t, a: String(ans), h: `<span>${t}</span>` };
}
function itTens(c) {
  // Patterns from the workbook's "Fill in the blanks" pages (place value + regrouping):
  //  0  1 ten + 7 ones = ▢ ones            1  14 ones = ▢ ten + ▢ ones          2  47 = ▢ tens + ▢ ones
  //  3  2 tens + 4 ones = ▢ ten + 14 ones  (break one ten into ones; the blank is the tens or the ones)
  //  4  4 tens + 17 ones = 5 tens + ▢ ones (join ones into tens; the blank is the tens or the ones)
  const { r, diff } = c, T = n => unit(c, n, 'ten'), O = n => unit(c, n, 'one');
  const bt = a => `${BX} ${word(c, 'ten', a !== 1)}`, bo = a => `${BX} ${word(c, 'one', a !== 1)}`;   // singular when the answer is 1
  const kind = r.pick({ easy: [0, 0, 1, 2], medium: [0, 1, 2, 3, 3], hard: [3, 3, 3, 4, 4, 1, 2] }[diff]); let h, a;
  if (kind === 0) { const x = r.int(1, diff === 'easy' ? 5 : 9), y = r.int(0, 9); h = `${T(x)} + ${O(y)} = ${bo(x * 10 + y)}`; a = String(x * 10 + y); }
  else if (kind === 1) { const n = diff === 'easy' ? r.int(11, 19) : r.int(20, 59), t = Math.floor(n / 10), o = n % 10;
    h = `${O(n)} = ${bt(t)} + ${bo(o)}`; a = `${T(t)} + ${O(o)}`; }
  else if (kind === 2) { const n = r.int(11, 99), t = Math.floor(n / 10), o = n % 10; h = `${n} = ${bt(t)} + ${bo(o)}`; a = `${T(t)} + ${O(o)}`; }
  else if (kind === 3) {                                          // x tens + y ones = (x−k) tens + (y+10k) ones
    const k = diff === 'hard' ? r.int(1, 2) : 1, x = r.int(k + 1, 9), y = r.int(0, 9), z = y + 10 * k;
    if (r.next() < .5) { h = `${T(x)} + ${O(y)} = ${bt(x - k)} + ${O(z)}`; a = String(x - k); }
    else { h = `${T(x)} + ${O(y)} = ${T(x - k)} + ${bo(z)}`; a = String(z); } }
  else {                                                          // x tens + (10k+z) ones = (x+k) tens + z ones
    const x = r.int(1, 7), k = r.int(1, 2), z = r.int(0, 9), y = 10 * k + z;
    if (r.next() < .5) { h = `${T(x)} + ${O(y)} = ${T(x + k)} + ${bo(z)}`; a = String(z); }
    else { h = `${T(x)} + ${O(y)} = ${bt(x + k)} + ${O(z)}`; a = String(x + k); } }
  return { cls: 'tn', k: h, a, h: `<span>${h}</span>` };
}
function itPhrase(c) {
  const q = Q(c), key = q.op === 'add' ? 'sumOf' : 'diffOf';
  return { cls: 'tn', k: key + q.a + q.b, a: String(q.ans), h: `<span>${c.t(key, { a: q.a, b: q.b })} ${BX}</span>` };
}
function itZero(c) {
  const q = Q(c), a = q.a;
  const [t, ans] = q.op === 'add' ? [`${a} + 0 = ${BX}`, a] : c.r.next() < .5 ? [`${a} − 0 = ${BX}`, a] : [`${a} − ${a} = ${BX}`, 0];
  return { cls: 'tn', k: t, a: String(ans), h: `<span>${t}</span>` };
}
function itOrder(c) {
  const { r, diff } = c, [lo, hi] = { easy: [1, 20], medium: [10, 50], hard: [10, 99] }[diff];
  const pool = r.shuffle(Array.from({ length: hi - lo + 1 }, (_, k) => lo + k)).slice(0, 5), asc = r.next() < .5;
  const sorted = pool.slice().sort((x, y) => asc ? x - y : y - x);
  return { cls: 'or', k: pool.join(), a: sorted.join(', '),
    h: `<div class="ol">${c.t(asc ? 'asc' : 'desc')}</div><div class="on">${pool.map(n => `<span>${n}</span>`).join('')}</div><div class="ob">${BX.repeat(5)}</div>` };
}
function itWord(c) {
  const { r, lang } = c; let q = Q(c);
  for (let i = 0; i < 30 && (q.a < 2 || q.b < 2); i++) q = Q(c);       // avoid “1 pencils”
  const N = r.pick(NAMES); let N2; do { N2 = r.pick(NAMES); } while (N2 === N);
  const p = { N: N[lang], N2: N2[lang], loc: N.loc, loc2: N2.loc, O: r.pick(OBJ)[lang], a: q.a, b: q.b, g: q.b, e: q.a };
  const text = r.pick(WT[q.op])[lang](p);
  return { cls: 'wp', k: text, a: `${q.a} ${q.sym} ${q.b} = ${ansTxt(q)}`,
    h: `<div class="wq">${text}</div><div class="wk"><div class="wa">${c.t('answer')} : ${LN}</div></div>` };
}

/* ============================================================ section assembly */
const cells = (items, cls = '') => items.map((it, i) =>
  `<div class="cell ${it.cls || ''} ${cls}"><span class="no">${i + 1}</span>${it.h}</div>`).join('');
const grid = (items, c, extra = '') => `<div class="grid g${c.cols} ${extra}" style="--rh:${c.rh}mm">${cells(items)}</div>`;
const sec = (instr, html, items, letter, pre = '') => ({ instr, html, ans: items.map(i => i.a), letter, pre });
const opInstr = c => c.t(c.ops.length === 1 ? { add: 'i_sum', sub: 'i_diff', mul: 'i_prod', div: 'i_quot', divr: 'i_divr' }[c.ops[0]]
  : c.ops.every(o => o === 'add' || o === 'sub') ? 'i_mix' : c.ops.every(o => o === 'div' || o === 'divr') ? 'i_quot' : 'i_all');
const make = (c, n, fn) => uniq(n, i => fn(c, i));

/* ============================================================ worksheet types
   ops   = operations the sheet can show ('*' = independent of the Operation setting)
   cols  = allowed “sums per row” (dc = default); need(x) = mm one sum needs, so wide numbers reduce the allowed columns
   minH(cols, x) = smallest row height in mm · top = extra mm above the grid.
   The page is filled automatically: rows = floor(space / minH), then rows are stretched to use all the space left. */
const ALL5 = ['add', 'sub', 'mul', 'div', 'divr'], isAS = o => o === 'add' || o === 'sub';
const exprLen = x => Math.max(...x.ops.map(o => isAS(o) ? (x.dg > 2 ? 2 * x.dg + 5 : 9) : o === 'mul' ? (x.mdl === 'x2' ? 10 : 9) : (x.mdl === 'x2' ? 11 : 10)));
const hNeed = x => exprLen(x) * 2.8 + (x.ops.includes('divr') ? 30 : 13) + 8;
const TYPES = [
  { id: 'column', ops: ['add', 'sub', 'mul'], cols: [3, 4, 5, 6], dc: 4,
    need: x => Math.max(x.ops.some(isAS) && x.dg > 2 ? x.dg : 2, x.ops.includes('mul') ? { tables: 3, x1: 4, x2: 5 }[x.mdl] : 2) * 6.5 + 11,
    minH: (k, x) => x.ops.includes('mul') && x.mdl === 'x2' ? 57 : 35,
    gen: c => { const it = make(c, c.n, itVert); return [sec(opInstr(c), grid(it, c), it)]; } },
  { id: 'horizontal', ops: ALL5, cols: [1, 2, 3, 4], dc: 2, need: hNeed, minH: () => 15,
    gen: c => { const it = make(c, c.n, itHoriz); return [sec(opInstr(c), grid(it, c), it)]; } },
  { id: 'longdiv', ops: ['div', 'divr'], cols: [2, 3, 4], dc: 3, need: x => (x.mdl === 'x2' ? 48 : 40), minH: () => 38,
    gen: c => { const it = make(c, c.n, itLongDiv); return [sec(opInstr(c), grid(it, c), it)]; } },
  { id: 'tables', ops: ['mul', 'div'], cols: [2, 3, 4], dc: 3, need: () => 44, minH: (k, x) => (x.diff === 'hard' ? 12 : 10) * 7 + 10,
    gen: c => {
      const hi = { easy: 5, medium: 10, hard: 12 }[c.diff], rowsN = c.diff === 'hard' ? 12 : 10, r = c.r;
      let pool = []; while (pool.length < c.n) pool = pool.concat(r.shuffle(Array.from({ length: hi - 1 }, (_, i) => i + 2)));
      const seen = new Set(), it = pool.slice(0, c.n).map(n => {
        const op = r.pick(c.ops), seq = Array.from({ length: rowsN }, (_, i) => i + 1);
        const ord = c.diff === 'hard' || seen.has(n) ? r.shuffle(seq) : seq; seen.add(n);     // repeats / hard: scrambled order
        return { cls: 'tbl', k: n + op + ord.join(''), a: `${n}: ` + ord.map(k => op === 'mul' ? n * k : k).join(', '),
          h: `<div class="tb"><div class="tt">${c.t(op === 'mul' ? 'tableOf' : 'divBy', { n })}</div>` +
             ord.map(k => `<div class="tl">${op === 'mul' ? `${n} × ${k}` : `${n * k} ÷ ${n}`} = ${BX}</div>`).join('') + '</div>' };
      });
      return [sec(c.t('i_tables'), grid(it, c), it)]; } },
  { id: 'picAdd', ops: ['add'], cols: [1, 2, 3], dc: 2, minH: k => [34, 42, 52][k - 1],
    gen: c => { const it = make(c, c.n, itPicAdd); return [sec(c.t('i_count'), grid(it, c), it)]; } },
  { id: 'picSub', ops: ['sub'], cols: [1, 2, 3], dc: 2, minH: k => [34, 42, 52][k - 1],
    gen: c => { const it = make(c, c.n, itPicSub); return [sec(c.t('i_cross'), grid(it, c), it)]; } },
  { id: 'breakup', ops: ['add'], cols: [2, 3, 4], dc: 3, minH: () => 33,
    gen: c => { const it = make(c, c.n, itBreak); return [sec(c.t('i_sum'), grid(it, c), it)]; } },
  { id: 'three', ops: ['add', 'sub'], cols: [1, 2, 3], dc: 2, minH: () => 15,
    gen: c => { const it = make(c, c.n, itThree); return [sec(c.t('i_find'), grid(it, c), it)]; } },
  { id: 'missing', ops: ALL5, cols: [1, 2, 3], dc: 2, need: x => exprLen(x) * 1.5 * 2.7 + 22, minH: () => 15,
    gen: c => { const it = make(c, c.n, itMissing); return [sec(c.t('i_fill'), grid(it, c), it)]; } },
  { id: 'tens', ops: '*', cols: [1, 2], dc: 1, minH: k => k === 2 ? 22 : 13,
    gen: c => { const it = make(c, c.n, itTens);
      return [sec(c.t('i_fill'), `<div class="lst c${c.cols}" style="--rh:${c.rh}mm;--cols:${c.cols}">${cells(it)}</div>`, it)]; } },
  { id: 'words', ops: ALL5, cols: [1, 2], dc: 1, minH: k => k === 2 ? 40 : 28,
    gen: c => { const it = make(c, c.n, itWord), dn = c.rh < (c.cols === 2 ? 44 : 40);        // compact text when rows are short
      return [sec(c.t('i_words'), `<div class="wps w${c.cols}${dn ? ' dn' : ''}" style="--rh:${c.rh}mm">${cells(it)}</div>`, it)]; } },
  { id: 'order', ops: '*', cols: [1, 2], dc: 1, minH: () => 33,
    gen: c => { const it = make(c, c.n, itOrder);
      return [sec(c.t('i_order'), `<div class="ogrid c${c.cols}" style="--rh:${c.rh}mm">${cells(it)}</div>`, it)]; } },
  { id: 'mental', ops: ['add', 'sub'], cols: [1, 2], dc: 1, minH: k => k === 2 ? 22 : 14,
    gen: c => {
      const B = [itThree, itTens, itPhrase, itZero, itMissing, itTens, itThree, itPhrase, itMissing, itTens, itThree, itZero];
      const it = uniq(c.n, i => B[i % B.length](c, i));
      return [sec(c.t('i_blanks'), `<div class="lst c${c.cols}" style="--rh:${c.rh}mm;--cols:${c.cols}">${cells(it)}</div>`, it)]; } },
  { id: 'drill', ops: ALL5, cols: [3, 4, 5], dc: 3, need: hNeed, minH: () => 14, top: 9,
    gen: c => { const it = make(c, c.n, itHoriz);
      const pre = `<div class="score"><span>${c.t('time')} : ${LN}</span><span>${c.t('score')} : ${LN} / ${it.length}</span></div>`;
      return [sec(`${opInstr(c)} ${c.t('i_fast')}`, grid(it, c), it, '', pre)]; } },
  { id: 'test', ops: ['add', 'sub'], cols: [1], dc: 1, fixed: true, minH: () => 1,
    gen: c0 => {                                                  // fixed grade-1 style mix; sections are dropped when the page is short
      const c = { ...c0, dg: 2 }, L = LETTERS[c.lang], g = (k, rh = 20) => ({ ...c, cols: k, rh }), add = { ...c, op: 'add', ops: ['add'] };
      const A = make(c, 5, itVert), Bm = make(c, 6, itMissing), D = make(c, 4, itHoriz), E = make(c, 1, itOrder);
      const C2 = uniq(3, i => itBreak(add, i));
      const out = [sec(opInstr(c), grid(A, g(5, 35)), A, L[0]), sec(c.t('i_fill'), grid(Bm, g(2, 15)), Bm, L[1]),
        sec(c.t('i_sum'), grid(C2, g(3, 36)), C2, L[2])];
      if (c.avail > 205) out.push(sec(opInstr(c), grid(D, g(2, 15)), D, L[3]));
      if (c.avail > 235) out.push(sec(c.t('i_order'), `<div class="ogrid c1">${cells(E)}</div>`, E, L[out.length]));
      return out; } },
];
const DEFAULT_SEL = ['column', 'horizontal', 'picAdd', 'picSub', 'missing', 'words'];

/* ============================================================ state */
const KEY = 'ws-state-v1';
const state = Object.assign({
  lang: 'en', tab: 'bundle', op: 'both', diff: 'easy', dg: 2, mdl: 'tables', copies: {}, key: true, head: true, foot: true,
  m: { t: 10, r: 12, b: 8, l: 12 }, cols: {}, rows: {},
  seed: 1 + Math.floor(Math.random() * 99999), sel: Object.fromEntries(DEFAULT_SEL.map(id => [id, true])),
}, (() => { try { const o = JSON.parse(localStorage.getItem(KEY)) || {}; delete o.seed; delete o.pages; return o; } catch { return {}; } })());   // seed is never restored: each launch = new sheet
for (const [k, v] of new URLSearchParams(location.search)) {      // optional share/debug link: ?tab=column&lang=ta&diff=hard&op=add&seed=7&pages=2
  if (k === 'seed' || k === 'dg') state[k] = +v || state[k]; else if (k in state && typeof state[k] === 'string') state[k] = v;
}
{ const q = new URLSearchParams(location.search);                    // ?tab=words&cols=2&rows=8 sets the layout of that tab
  for (const k of ['cols', 'rows']) if (q.get(k) && q.get('tab')) state[k][q.get('tab')] = +q.get(k);
  if (q.get('pages')) TYPES.forEach(t => { if (!q.get('tab') || q.get('tab') === 'bundle' || q.get('tab') === t.id) state.copies[t.id] = Math.min(10, +q.get('pages') || 1); }); }
if (state.tab !== 'bundle' && !TYPES.some(t => t.id === state.tab)) state.tab = 'bundle';
const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ ...state, seed: undefined })); } catch { /* private mode */ } };
const tr = (k, p) => { const v = S[state.lang][k] ?? S.en[k]; return typeof v === 'function' ? v(p) : v; };
const typeName = id => tr('t_' + id);
const opsOf = o => o === 'both' ? ['add', 'sub'] : o === 'all' ? ['add', 'sub', 'mul', 'div'] : [o];
const copiesOf = ty => Math.max(1, Math.min(10, (state.copies[ty.id] | 0) || 1));
const supports = ty => ty.ops === '*' || opsOf(state.op).some(o => ty.ops.includes(o));
const effOps = ty => {                                           // operations this sheet will actually use
  const want = opsOf(state.op); if (ty.ops === '*') return want;
  const ok = ty.ops.filter(o => want.includes(o)); return ok.length ? ok : [ty.ops[0]];
};
const OPSYM = { add: '+', sub: '−', mul: '×', div: '÷', divr: '÷' };

/* ============================================================ document */
const MARGIN_DEFAULT = { t: 10, r: 12, b: 8, l: 12 };
function applyMargins() {
  const st = document.documentElement.style;
  for (const k of ['t', 'r', 'b', 'l']) {
    const v = Math.max(0, Math.min(25, +state.m[k]));
    st.setProperty('--m' + k, (Number.isFinite(v) ? v : MARGIN_DEFAULT[k]) + 'mm');
  }
}
const hintsFor = ty => ({ ops: effOps(ty), dg: state.dg, mdl: state.mdl, diff: state.diff });
function colsAllowed(ty) {                                       // wide numbers / narrow paper → fewer sums per row
  if (!ty.need) return ty.cols;
  const uw = 210 - (+state.m.l || 0) - (+state.m.r || 0), max = Math.floor(uw / ty.need(hintsFor(ty)));
  const ok = ty.cols.filter(n => n <= max); return ok.length ? ok : [ty.cols[0]];
}
const colsOf = ty => { const ok = colsAllowed(ty); return ok.includes(state.cols[ty.id]) ? state.cols[ty.id] : ok.includes(ty.dc) ? ty.dc : ok[ok.length - 1]; };
const titleOf = ty => ty.id === 'test' ? tr('test') : typeName(ty.id);
const availMemo = new Map();
function availBody(title) {                                         // mm of free height between header and footer (memoised)
  const key = `${title}|${state.head}|${state.foot}|${state.lang}|${JSON.stringify(state.m)}`;
  if (availMemo.has(key)) return availMemo.get(key);
  applyMargins();                                                  // measure with the current margins
  const box = document.createElement('div');
  box.style.cssText = 'position:absolute;left:-9999px;top:0;visibility:hidden';
  box.innerHTML = pageHtml(title, [], 1, 1, '');
  document.body.appendChild(box);
  const h = box.querySelector('.pb').clientHeight * 25.4 / 96;
  box.remove(); availMemo.set(key, h); return h;
}
function layoutFor(ty) {                                            // columns, rows (capped by width / height) and stretched row height
  const cols = colsOf(ty), avail = availBody(titleOf(ty)), space = avail - 9.5 - (ty.top || 0) - 1.5;
  const maxRows = Math.max(1, Math.floor(space / ty.minH(cols, hintsFor(ty)))), want = state.rows[ty.id];
  const rows = want > 0 ? Math.min(want, maxRows) : maxRows;
  return { cols, avail, space, maxRows, rows, rh: Math.floor(space / rows * 10) / 10 };
}
function ctxFor(ty, p) {
  const ops = effOps(ty), L = layoutFor(ty), c = { r: RNG(hash(`${state.seed}|${ty.id}|${p}`)), ops, op: ops.length === 1 ? ops[0] : 'mix',
    diff: state.diff, dg: state.dg, mdl: state.mdl, lang: state.lang, t: tr, cols: L.cols, avail: L.avail, rows: L.rows, rh: L.rh };
  c.n = c.rows * c.cols;
  return c;
}
function pageHtml(title, secs, n, total, body) {
  const meta = `${tr(state.diff)} · #${state.seed}`;
  const head = state.head
    ? `<div class="nm"><span>${tr('name')} :</span><i></i><span>${tr('date')} :</span><i class="d"></i></div>` : '';
  const foot = state.foot ? `<footer class="pf"><span>${meta}</span><span>${tr('page')} ${n} / ${total}</span></footer>` : '';
  return `<div class="pwrap"><section class="page"><header class="ph"><div class="pt">${title}</div>${head}</header>` +
    `<div class="pb">${body ?? secs.map(secHtml).join('')}</div>${foot}</section></div>`;
}
const secHtml = s => `<div class="sec">${s.pre}<div class="si">${s.letter ? `<b>${s.letter}.</b> ` : ''}${s.instr}</div>${s.html}</div>`;

function keyPages(entries, cap) {                                       // pack answer blocks into pages by estimated height
  const pages = []; let cur = [], used = 0;
  for (const e of entries) {
    const len = e.groups.reduce((n, g) => n + g.ans.reduce((m, a) => m + String(a).length + 4, 0), 0);
    const cost = 2 + e.groups.length * .6 + Math.ceil(len / 68);
    if (used + cost > cap && cur.length) { pages.push(cur); cur = []; used = 0; }
    cur.push(e); used += cost;
  }
  if (cur.length) pages.push(cur);
  return pages;
}
const keyBlock = e => `<div class="kp"><div class="kt">${e.title}</div>` + e.groups.map(g =>
  `${g.letter ? `<div class="ks">${g.letter}.</div>` : ''}<div class="ka">${g.ans.map((a, i) => `<span><b>${i + 1}</b>${a}</span>`).join('')}</div>`).join('') + '</div>';

function buildDoc() {
  const list = state.tab === 'bundle' ? TYPES.filter(t => state.sel[t.id] && supports(t)) : [TYPES.find(t => t.id === state.tab)];
  const pages = [];
  list.forEach(ty => { for (let p = 0; p < copiesOf(ty); p++) pages.push({ ty, secs: ty.gen(ctxFor(ty, p)) }); });
  if (!pages.length) return '';
  const entries = state.key ? pages.map((pg, i) => ({
    title: `${tr('page')} ${i + 1} · ${typeName(pg.ty.id)}`, groups: pg.secs.map(s => ({ letter: pg.secs.length > 1 ? s.letter : '', ans: s.ans })) })) : [];
  const kp = keyPages(entries, 36 * availBody(tr('keyTitle')) / 236), total = pages.length + kp.length;
  const out = pages.map((pg, i) => pageHtml(titleOf(pg.ty), pg.secs, i + 1, total));
  kp.forEach((es, j) => out.push(pageHtml(`${tr('keyTitle')}${kp.length > 1 ? ` (${j + 1}/${kp.length})` : ''}`, null, pages.length + j + 1, total, es.map(keyBlock).join(''))));
  return out.join('');
}

/* ============================================================ UI */
const seg = (k, opts, cur, cls = '') => `<div class="seg ${cls}" role="group">${opts.map(([v, label]) =>
  `<button data-k="${k}" data-v="${v}" aria-pressed="${String(v) === String(cur)}">${label}</button>`).join('')}</div>`;

function renderTabs() {
  const tabs = [['bundle', tr('bundle')], ...TYPES.map(t => [t.id, typeName(t.id)])];
  $('#tabs').innerHTML = tabs.map(([id, label]) =>
    `<button role="tab" data-tab="${id}" aria-selected="${state.tab === id}">${label}</button>`).join('');
  const sel = $('#tabs [aria-selected=true]'); if (sel) sel.scrollIntoView({ inline: 'center', block: 'nearest' });
}
const copySel = t => `<select class="cs" data-copies="${t.id}" title="${tr('sheetsTip')}" aria-label="${tr('sheetsTip')} – ${typeName(t.id)}">${
  Array.from({ length: 10 }, (_, i) => i + 1).map(n => `<option value="${n}" ${copiesOf(t) === n ? 'selected' : ''}>📄 ${n}</option>`).join('')}</select>`;
const rowSel = t => { const L = layoutFor(t); return t.fixed ? '' :
  `<select class="cs" data-rows="${t.id}" title="${tr('rowsPer')}" aria-label="${tr('rowsPer')} – ${typeName(t.id)}"><option value="0">↕ ${tr('autoMax', L.maxRows)}</option>${
  Array.from({ length: L.maxRows }, (_, i) => i + 1).map(n => `<option value="${n}" ${state.rows[t.id] === n ? 'selected' : ''}>↕ ${n}</option>`).join('')}</select>`; };
const colSel = t => colsAllowed(t).length < 2 ? '' : `<select class="cs" data-cols="${t.id}" title="${tr('perRow')}" aria-label="${tr('perRow')} – ${typeName(t.id)}">${
  colsAllowed(t).map(n => `<option value="${n}" ${n === colsOf(t) ? 'selected' : ''}>↔ ${n}</option>`).join('')}</select>`;
function renderPanel() {
  const ty = TYPES.find(t => t.id === state.tab), bundle = state.tab === 'bundle';
  let note = '';
  if (ty) note = ty.ops === '*' ? tr('fixedAny') : supports(ty) ? '' : tr('onlyFor', { n: [...new Set(ty.ops.map(o => o === 'divr' ? 'div' : o))].map(o => tr(o)).join(' / ') });
  const mdlOn = ['mul', 'div', 'divr', 'all'].includes(state.op);
  const chips = bundle ? `<div class="fld"><div class="lbl">${tr('typesTitle')}
      <button class="mini" data-all="1">${tr('all')}</button><button class="mini" data-all="0">${tr('none')}</button></div>
      <div class="types">${TYPES.map(t => `<label class="${supports(t) ? '' : 'off'}"><input type="checkbox" data-sel="${t.id}"
        ${state.sel[t.id] && supports(t) ? 'checked' : ''} ${supports(t) ? '' : 'disabled'}>${typeName(t.id)}
        <span class="op">${t.ops === '*' ? '' : [...new Set(t.ops.map(o => OPSYM[o]))].join('')}</span>${colSel(t)}${rowSel(t)}${copySel(t)}</label>`).join('')}</div></div>` : '';
  const perRow = ty && !ty.fixed ? `<div class="fld"><div class="lbl">${tr('perRow')} / ${tr('rowsPer')} <button class="mini" data-autolayout="1">${tr('autoLayout')}</button></div>
      ${colsAllowed(ty).length > 1 ? seg('cols', colsAllowed(ty).map(n => [n, n]), colsOf(ty)) : ''}
      <div class="row" style="margin-top:8px"><label class="lbl" style="margin:0">${tr('rowsPer')}</label>${rowSel(ty)}</div></div>` : '';
  $('#panel').innerHTML = `<summary>⚙ ${tr('options')}</summary><div class="body">
    <div class="fld"><div class="lbl">${tr('operation')}</div>${seg('op', [['add', '+ ' + tr('add')], ['sub', '− ' + tr('sub')], ['both', '± ' + tr('both')],
      ['mul', '× ' + tr('mul')], ['div', '÷ ' + tr('div')], ['divr', '÷ ' + tr('divr')], ['all', '+−×÷ ' + tr('all')]], state.op, 'wrap')}
      ${note ? `<p class="hint">${note}</p>` : ''}</div>
    ${mdlOn ? `<div class="fld"><div class="lbl">${tr('mdl')}</div>${seg('mdl', ['tables', 'x1', 'x2'].map(v => [v, tr('mdl_' + v)]), state.mdl, 'wrap')}</div>` : ''}
    <div class="fld"><div class="lbl">${tr('digits')}</div>${seg('dg', [[2, tr('dg_2')], [3, '3'], [4, '4'], [5, '5']], state.dg)}</div>
    <div class="fld"><div class="lbl">${tr('difficulty')}</div>${seg('diff', [['easy', tr('easy')], ['medium', tr('medium')], ['hard', tr('hard')]], state.diff)}</div>
    ${perRow}
    ${ty ? `<div class="fld"><div class="row"><label class="lbl" style="margin:0">${tr('sheets')}</label>${copySel(ty)}</div></div>` : ''}
    ${chips}
    <div class="fld"><div class="lbl">${tr('paper')} <button class="mini" data-reset="1">${tr('reset')}</button></div>
      <div class="mgrid">${[['t', 'mTop'], ['r', 'mRight'], ['b', 'mBottom'], ['l', 'mLeft']].map(([k, l]) =>
        `<label>${tr(l)}<input class="num" type="number" min="0" max="25" step="1" inputmode="numeric" data-m="${k}" value="${state.m[k]}"></label>`).join('')}</div></div>
    <div class="row"><label class="chk"><input type="checkbox" data-chk="key" ${state.key ? 'checked' : ''}>${tr('answerKey')}</label>
      <label class="chk"><input type="checkbox" data-chk="head" ${state.head ? 'checked' : ''}>${tr('header')}</label>
      <label class="chk"><input type="checkbox" data-chk="foot" ${state.foot ? 'checked' : ''}>${tr('footer')}</label></div>
    <div class="fld"><label for="seedIn">${tr('seed')}</label><input id="seedIn" class="num" type="number" min="1" max="999999" inputmode="numeric" value="${state.seed}">
      <p class="hint">${tr('seedHint')}</p></div></div>`;
}
function renderChrome() {
  document.documentElement.lang = state.lang;
  document.title = tr('appTitle');
  $('#appTitle').textContent = tr('appTitle');
  $('#newBtn').textContent = tr('newSheet'); $('#printBtn').textContent = tr('print'); $('#installBtn').textContent = tr('install');
  document.querySelectorAll('#langSeg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.lang === state.lang));
}
function renderPreview() {
  applyMargins();
  const html = buildDoc();
  $('#preview').innerHTML = html || `<p class="empty">${tr('empty')}</p>`;
  applyScale();
}
function applyScale() {
  const w = ($('#preview').clientWidth || window.innerWidth) - 16;
  const s = Math.max(.3, Math.min(1, w / (210 * 96 / 25.4)));
  document.documentElement.style.setProperty('--s', s.toFixed(3));
}
const renderAll = () => { renderChrome(); renderTabs(); renderPanel(); renderPreview(); };
const refresh = () => { save(); renderPanel(); renderPreview(); };
const relayout = () => { applyMargins(); renderPreview(); };

/* ============================================================ events */
$('#tabs').addEventListener('click', e => {
  const b = e.target.closest('[data-tab]'); if (!b) return;
  state.tab = b.dataset.tab; save(); renderTabs(); renderPanel(); renderPreview(); window.scrollTo({ top: 0 });
});
$('#langSeg').addEventListener('click', e => {
  const b = e.target.closest('[data-lang]'); if (!b) return;
  state.lang = b.dataset.lang; save(); renderAll();
});
$('#panel').addEventListener('click', e => {
  if (e.target.closest('.cs')) { e.stopPropagation(); return; }
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.k === 'cols') { state.cols[state.tab] = +b.dataset.v; refresh(); }
  else if (b.dataset.autolayout) { state.cols = {}; state.rows = {}; refresh(); }
  else if (b.dataset.reset) { state.m = { ...MARGIN_DEFAULT }; refresh(); }
  else if (b.dataset.k) { state[b.dataset.k] = (b.dataset.k === 'pages' || b.dataset.k === 'dg') ? +b.dataset.v : b.dataset.v; refresh(); }
  else if (b.dataset.all) { TYPES.forEach(t => { state.sel[t.id] = b.dataset.all === '1'; }); refresh(); }
});
$('#panel').addEventListener('change', e => {
  const t = e.target;
  if (t.dataset.copies) { if (+t.value > 1) state.copies[t.dataset.copies] = +t.value; else delete state.copies[t.dataset.copies]; save(); renderPreview(); }
  else if (t.dataset.rows) { if (+t.value > 0) state.rows[t.dataset.rows] = +t.value; else delete state.rows[t.dataset.rows]; save(); renderPanel(); renderPreview(); }
  else if (t.dataset.cols) { state.cols[t.dataset.cols] = +t.value; save(); renderPanel(); renderPreview(); }
  else if (t.dataset.m) { state.m[t.dataset.m] = Math.max(0, Math.min(25, parseFloat(t.value) || 0)); save(); renderPreview(); }
  else if (t.dataset.sel) { state.sel[t.dataset.sel] = t.checked; refresh(); }
  else if (t.dataset.chk) { state[t.dataset.chk] = t.checked; refresh(); }
  else if (t.id === 'seedIn') { state.seed = Math.max(1, Math.min(999999, parseInt(t.value, 10) || 1)); refresh(); }
});
$('#newBtn').addEventListener('click', () => { state.seed = 1 + Math.floor(Math.random() * 99999); refresh(); });
$('#printBtn').addEventListener('click', () => {
  const old = document.title;
  document.title = `Worksheet_${new Date().toISOString().slice(0, 10)}_${state.diff}_${state.seed}`;   // default PDF file name
  const restore = () => { document.title = old; window.removeEventListener('afterprint', restore); };
  window.addEventListener('afterprint', restore);
  window.print();
});
window.addEventListener('resize', applyScale);
window.addEventListener('beforeprint', () => document.documentElement.style.setProperty('--s', '1'));
window.addEventListener('afterprint', applyScale);

/* ============================================================ PWA */
let deferred = null;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; $('#installBtn').hidden = false; });
$('#installBtn').addEventListener('click', async () => {
  if (!deferred) return; deferred.prompt(); await deferred.userChoice; deferred = null; $('#installBtn').hidden = true;
});
window.addEventListener('appinstalled', () => { $('#installBtn').hidden = true; });
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});

if (window.matchMedia('(min-width:900px)').matches) $('#panel').open = true;
renderAll();

/* developer self-test: open index.html#selftest – samples thousands of settings and reports any clipped content on an A4 page */
if (location.hash === '#selftest') {
  const bad = [], saved = JSON.stringify(state), R = RNG(2024), N = +(new URLSearchParams(location.search).get('n')) || 2500;
  const margins = [{ t: 5, r: 5, b: 5, l: 5 }, MARGIN_DEFAULT, { t: 20, r: 20, b: 20, l: 20 }];
  for (let n = 0; n < N; n++) {
    const ty = R.pick(TYPES), m = R.pick(margins), lang = R.pick(['en', 'ta']), diff = R.pick(['easy', 'medium', 'hard']);
    const op = R.pick(['add', 'sub', 'both', 'mul', 'div', 'divr', 'all']), dg = R.pick([2, 2, 3, 4, 5]), mdl = R.pick(['tables', 'x1', 'x2']);
    Object.assign(state, { lang, diff, op, dg, mdl, tab: ty.id, seed: 1 + n, key: true, copies: {}, head: true, foot: true, m: { ...m }, cols: {} });
    const all = colsAllowed(ty); state.cols[ty.id] = R.pick(all);
    const mr = layoutFor(ty).maxRows; if (!ty.fixed && R.next() < .6) state.rows[ty.id] = R.int(1, mr);
    renderPreview();
    const tag = `${ty.id}/c${state.cols[ty.id]}/r${state.rows[ty.id] || 'a'}/${lang}/${diff}/${op}/dg${dg}/${mdl}/m${m.t}`;
    document.querySelectorAll('.pb').forEach((el, i) => { if (el.scrollHeight > el.clientHeight + 1) bad.push(`${tag}#${i} page ${el.scrollHeight}>${el.clientHeight}`); });
    document.querySelectorAll('.cell').forEach(el => {
      if (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) bad.push(`${tag} cell ${el.scrollWidth}x${el.scrollHeight}>${el.clientWidth}x${el.clientHeight} "${el.textContent.slice(0, 24)}"`);
    });
  }
  Object.assign(state, JSON.parse(saved)); renderAll();
  document.body.dataset.overflow = bad.length ? `${bad.length}: ` + [...new Set(bad)].slice(0, 30).join(' | ') : 'OK ' + N;
}
})();
