# Developer guide

How the Maths Worksheets app works and how to change it safely.
Everything is plain browser JavaScript/CSS – **no build step, no dependencies**. Edit a file, refresh the page.

> Line numbers drift, so this guide refers to **function and constant names**. Use your editor's search.

---

## 1. Files

| File | Purpose |
|---|---|
| `index.html` | Static shell: app bar (language switch, install button), tab strip, options panel (`<details id="panel">`), preview container, bottom action bar. All dynamic content is injected by `app.js`. |
| `style.css` | Part 1: app UI (mobile first, desktop ≥ 900 px). Part 2: the A4 sheet (`.pwrap`, `.page`, cell/grid styles). Part 3: `@media print`. |
| `app.js` | The whole application in one IIFE (see §2). |
| `fonts.css` | Embedded Tamil font subset (`font-family: "TamilSub"`, Regular + Bold, `unicode-range` = Tamil only). Generated – see §10. |
| `sw.js` | Service worker: stale-while-revalidate cache of the app shell. **Bump `VERSION` on every release.** |
| `manifest.webmanifest`, `icons/` | PWA metadata and icons. |

---

## 2. `app.js` structure (top to bottom)

```
helpers          $, hash(), RNG(), BX / LN constants, uniq()
strings          S = { en:{…}, ta:{…} }, UNIT, LETTERS, NAMES, OBJ, WT (word-problem templates), EMO
generators       pAdd pSub pAddN pSubN pMul divParts ansTxt Q()      ← pure number logic
item builders    itVert itHoriz itLongDiv itPicAdd itPicSub itBreak itThree itMissing itTens itPhrase itZero itOrder itWord
sections         cells() grid() sec() opInstr() make()
TYPES            the worksheet types (one object each) + DEFAULT_SEL
state            state, save(), tr(), opsOf/supports/effOps, URL params
document         applyMargins, colsAllowed/colsOf, availBody, layoutFor, ctxFor, pageHtml, keyPages, buildDoc
UI               seg(), renderTabs/Panel/Chrome/Preview, applyScale, events
PWA              install prompt + service-worker registration
self-test        runs when location.hash === '#selftest'
```

### Data flow

```
state ──► buildDoc()
            for each worksheet type (single tab, or ticked types in Bundle) × copiesOf(type) sheets:
              ctxFor(type, pageIndex)  ──► c  (ctx: seeded RNG, ops, difficulty, rows/cols/row-height …)
              type.gen(c)              ──► [section, …]
            pageHtml(...)  for every page   +   answer-key pages
          ──► HTML string ──► #preview.innerHTML
```

Printing needs no extra code: the preview **is** the print output (CSS `@media print` hides the app UI and removes
the on-screen scaling).

---

## 3. Core concepts

### 3.1 Seeded randomness
`RNG(seed)` is mulberry32 and returns `{ next, int(lo,hi), pick(arr), shuffle(arr) }`.
Each page gets its own RNG: `RNG(hash(`${state.seed}|${type.id}|${pageIndex}`))`.
Therefore **the same settings + sheet number always give the same sheet**, and tabs/pages don't disturb each other.
Never use `Math.random()` inside generators (only for picking a *new* seed in `state.seed`).

> Changing the *order or number* of `r.next()/r.int()` calls changes what an existing seed produces. That is fine, but
> don't expect old sheet numbers to reproduce after such a change.

### 3.2 Operations
Concrete operations: `add sub mul div divr` (divr = division with remainder).
The **Operation** setting (`state.op`) can also be `both` (add+sub) or `all` (add, sub, mul, div).

* `opsOf(state.op)` → array of concrete operations.
* Each type declares `ops` (what it *can* show) or `'*'` (independent of the setting).
* `supports(type)` – is the type usable for the current setting (greys it out in the Bundle).
* `effOps(type)` → the operations the sheet actually uses = `type.ops ∩ opsOf(state.op)`;
  falls back to `type.ops[0]` on a single tab whose type doesn't support the setting.
* In the ctx: `c.ops` (array) and `c.op` (`'add'`…`'divr'`, or `'mix'` when more than one).

### 3.3 The question generator `Q(c)`
`Q(c)` picks one op from `c.ops` and returns `{ op, a, b, sym, ans, rem }`.
Ranges come from:

| Setting | Meaning |
|---|---|
| `c.diff` easy / medium / hard | 1–2 digit: easy = within 10, medium = within 20 / tens / no carry, hard = 2-digit with carry/borrow. For 3–5 digits: none / some / many carries. For × ÷: table size or number size. |
| `c.dg` (2–5) | digits for + − (`2` = the original Grade 1 generators `pAdd/pSub`; ≥ 3 uses `pAddN/pSubN`) |
| `c.mdl` `tables` / `x1` / `x2` | × ÷ range: tables to 12, 2–3 digit × 1 digit, 2–3 digit × 2 digit (`pMul`, `divParts`) |

For division, `a = b * q (+ rem)`, `ans = q`; use `ansTxt(q)` to print `q` or `q R rem`.

### 3.4 Items (the unit of a question)
Every `it…(c, i)` builder returns:

```js
{ cls: 'hs',          // CSS class on the cell (see style.css)
  h:   '<span>…</span>',   // inner HTML of the cell
  a:   '12',               // answer text for the answer key
  k:   'add3_9' }          // uniqueness key – identical keys are re-rolled by uniq()
```

`make(c, n, fn)` = `uniq(n, i => fn(c, i))` creates *n* distinct items (it gives up on uniqueness after 80 duplicates so it
never loops forever). `cells(items)` wraps them in numbered `.cell` divs; `grid(items, c)` puts them in a CSS grid
with `c.cols` columns and row height `c.rh` mm.

Blank answer boxes are `BX` (`<i class="bx">`), answer lines are `LN`.

### 3.5 Sections and pages
`sec(instr, html, items, letter?, pre?)` → `{ instr, html, ans[], letter, pre }`.
A type's `gen(c)` returns an **array of sections** for **one page**. `pageHtml()` wraps sections in the A4 frame
(header with Name/Date, body, footer). The *Mixed Test* returns several sections (A–E); every other type returns one.

### 3.6 Layout engine: filling the page
`layoutFor(type)` decides rows × columns so the page is used fully:

```
avail   = height of the page body in mm, measured from a hidden probe page (availBody)
space   = avail − 9.5 (instruction line) − type.top − 1.5 (safety)
cols    = colsOf(type)                      ← user choice, clamped by colsAllowed()
maxRows = floor(space / type.minH(cols, hints))
rows    = user's "rows per page" (capped at maxRows) or maxRows (Auto)
rh      = space / rows                      ← rows are stretched to use all the space
n       = rows × cols                       ← number of questions generated
```

* `colsAllowed(type)`: if the type has `need(hints)` (mm one sum needs), columns are limited to
  `floor(usableWidth / need)` where `usableWidth = 210 − marginLeft − marginRight`. This is why 5-digit numbers allow
  fewer columns.
* `hintsFor(type)` = `{ ops, dg, mdl, diff }` – the settings that affect size, passed to `need()` / `minH()`.
* `availBody()` measures the DOM, so it **must run with the current margins applied** (it calls `applyMargins()` itself)
  and results are memoised by title/header/footer/language/margins.

### 3.7 Margins and CSS variables

| Variable | Set by | Used for |
|---|---|---|
| `--mt --mr --mb --ml` | `applyMargins()` on `:root` | `.page` padding (mm) |
| `--s` | `applyScale()` | on-screen scale of the A4 page to fit the screen width; forced to 1 when printing |
| `--rh` | inline style on the grid/list wrapper | row height of cells (`height: var(--rh, <fallback>)`) |
| `--cols` | inline style on `.lst` | column count of list layouts |

A4 is **210 × 296 mm** (296, not 297, on purpose: avoids a blank trailing page in Chrome). Page structure:
`.pwrap` (sized box used for screen scaling) → `.page` (210×296 mm, `overflow:hidden`) → `.ph` header, `.pb` body, `.pf` footer.

---

## 4. A worksheet type (`TYPES` entry)

```js
{ id: 'horizontal',                 // key for tabs, state.cols/rows, strings (t_horizontal) and the seed
  ops: ALL5,                        // supported operations, or '*' (ignores the Operation setting)
  cols: [1, 2, 3, 4], dc: 2,        // allowed "sums per row" and the default
  need: hNeed,                      // optional: mm needed by one sum (limits columns for wide numbers)
  minH: (k, x) => 15,               // smallest row height in mm for k columns (x = hintsFor(type))
  top: 9,                           // optional: extra mm used above the grid (e.g. the Speed Drill score line)
  fixed: true,                      // optional: fixed layout, no rows/cols controls (Mixed Test)
  gen: c => { const it = make(c, c.n, itHoriz); return [sec(opInstr(c), grid(it, c), it)]; } }
```

The ctx `c` passed to `gen`:

| Field | Meaning |
|---|---|
| `c.r` | seeded RNG |
| `c.ops`, `c.op` | operations (array) / single op or `'mix'` |
| `c.diff`, `c.dg`, `c.mdl` | difficulty, digits, × ÷ range |
| `c.lang`, `c.t(key, params)` | language and string lookup |
| `c.cols`, `c.rows`, `c.n`, `c.rh`, `c.avail` | layout (see §3.6) |

---

## 5. Recipes

### 5.1 Add a new worksheet type
1. **Item builder** (if the question shape is new) next to the other `it…` functions:
   ```js
   function itDoubles(c) {
     const n = c.r.int(1, 20);
     return { cls: 'hs', k: 'd' + n, a: String(n * 2), h: `<span>${n} + ${n} =</span>${BX}` };
   }
   ```
   Reusing an existing `cls` (`hs`, `vs`, `pic`, `bu`, `tn`, `ld`, `wp`, `or`, `tbl`) needs no new CSS.
2. **Type entry** in `TYPES`:
   ```js
   { id: 'doubles', ops: ['add'], cols: [1, 2, 3], dc: 2, minH: () => 15,
     gen: c => { const it = make(c, c.n, itDoubles); return [sec(c.t('i_fill'), grid(it, c), it)]; } },
   ```
3. **Strings:** add `t_doubles: 'Doubles'` (and the Tamil text) to **both** `S.en` and `S.ta`. The tab label is
   `tr('t_' + id)`.
4. *(optional)* add the id to `DEFAULT_SEL` so it is ticked in the Bundle by default.
5. **New look?** Add CSS for the new `cls` in `style.css` (use `height: var(--rh, <fallback>)` so rows stretch).
6. Run the **self-test** (§8).

### 5.2 Add a new instruction / UI string
Add the key to `S.en` **and** `S.ta` (`tr()` falls back to English if a Tamil key is missing, but don't rely on it).
Strings may be functions for parameters: `tableOf: p => \`Table of ${p.n}\``, called as `c.t('tableOf', { n: 7 })`.

### 5.3 Add a new operation (e.g. `square`)
1. Extend `Q(c)` with the new `op` (return `{ op, a, b, sym, ans, rem }`), keep the answer in `ans`.
2. Add it to `opsOf()` (if it joins `both`/`all`) or as a new `state.op` button in `renderPanel()` (the `seg('op', …)` list), plus
   strings (`square`, `i_…`).
3. Add it to `OPSYM` (symbol shown on Bundle chips) and to the `ops` arrays of the types that can display it.
4. Teach the item builders that need special layout (`itVert`, `itHoriz`, `itMissing`, `itWord` + `WT.square` templates).
5. Update `opInstr()` so the instruction line is right.
6. Check `exprLen()`/`need()` if the new expressions are wider than the existing ones.

### 5.4 Change difficulty ranges
Edit the generator functions only – `pAdd`, `pSub`, `pAddN`, `pSubN`, `pMul`, `divParts`.
Keep the invariants: subtraction never goes negative, division is exact unless `divr`, and `a` stays within the
digit count the layout expects (`need()`/`minH()` assume it).

### 5.5 Add a language
1. Add `S.<code>` with **every** key of `S.en`; add `<code>` entries to `UNIT`, `LETTERS`, every `WT` template, and each
   `NAMES` / `OBJ` object.
2. Add a button to the language switch in `index.html` (`<button data-lang="xx">`) – the handler is generic.
3. Fonts: if the script is not covered by common system fonts, embed a subset (§10) and add its family to `--font`.
4. Word problems use pre-computed forms (`NAMES[i].loc` is the Tamil "with <name>" form). For a language with grammar cases,
   store the needed forms in the data instead of generating them with code.

### 5.6 Change page margins / defaults
`MARGIN_DEFAULT` in `app.js` plus the CSS fallbacks in `.page { padding: var(--mt, 10mm) … }`. The panel limits margins to 0–25 mm
(`max` on the inputs and the `Math.min(25, …)` clamps); wider margins started wrapping Tamil text – raise the limit only after
running the self-test with larger margins in `margins[]`.

### 5.7 Change the number of questions
Don't hard-code counts. Adjust `minH` (smaller = more rows) and `cols`; `layoutFor` computes `n`.
If text may wrap, also add a compact CSS class (see `.wps.dn` for word problems, which switches to a smaller font when rows are short).

### 5.8 Answer key
Every item's `a` is shown as `<b>index</b> answer`. `keyPages()` packs blocks into pages by an estimated height
(`cost` in lines, capacity `36 × availBody / 236`). Change the key layout in `keyBlock()` / `.kp*` CSS.

---

## 6. State and persistence

`state` (defaults in the `Object.assign({...})` near `KEY`) is saved to `localStorage['ws-state-v1']` by `save()` (without `seed`) after every change, and merged over the defaults at start-up. To test restore in headless Chrome, write the JSON to `localStorage` from a throw-away `file://` page using the same `--user-data-dir`, then load `index.html`.

| Key | Meaning |
|---|---|
| `lang` `tab` `op` `diff` `dg` `mdl` `seed` | basic settings (`seed` is **never** restored from storage – every launch gets a new sheet number) |
| `key` `head` `foot` | answer key, Name/Date line, footer toggles |
| `m` `{t,r,b,l}` | margins (mm) |
| `cols`, `rows` | per-type overrides `{ typeId: number }` (missing = default / Auto) |
| `copies` | number of sheets per type `{ typeId: 1–10 }` (missing = 1); read through `copiesOf(type)`, used in `buildDoc()`; each copy `p` has its own RNG (`…|${type.id}|${p}`) |
| `sel` | Bundle ticks `{ typeId: true }` |

New settings: add a default, add UI in `renderPanel()` (+ a handler in the `#panel` click/change listeners), read it in
`ctxFor()` or the generators. Old saved states are merged over the defaults, so adding keys is safe. If you *change the meaning*
of an existing key, change `KEY` (e.g. `ws-state-v2`) so old values are ignored.

URL parameters are read right after state is loaded (see `URLSearchParams` blocks); extend them there.

---

## 7. UI code

* `renderAll()` = `renderChrome` (titles/buttons text) + `renderTabs` + `renderPanel` + `renderPreview`.
* `refresh()` = save + re-render panel and preview (use after a setting changes).
* Event handling is delegated on `#tabs`, `#langSeg`, `#panel`; controls carry `data-*` attributes (`data-k`, `data-v`, `data-sel`, `data-cols`,
  `data-rows`, `data-copies`, `data-m`, `data-chk`, `data-reset`, `data-autolayout`).
* `seg(key, [[value,label],…], current, 'wrap')` builds a segmented button group.
* Desktop layout (≥ 900 px) is plain CSS grid; on phones the panel is a collapsible `<details>`.

---

## 8. Testing

There is no test runner; there is a built-in **layout fuzz test** because the worst bugs here are visual (content clipped on the paper).

```
index.html#selftest              # 2500 random configurations
index.html?n=4000#selftest       # more
```

It randomises type, operation, difficulty, digits, range, language, margins (5 / default / 20 mm), columns and rows, renders each, and
flags any `.pb` page body or `.cell` whose `scrollHeight/Width` exceeds its box. Result: `<body data-overflow="OK 4000">` or
`"<count>: <first problems…>"`. Headless run:

```bash
google-chrome --headless=new --no-sandbox --disable-gpu --virtual-time-budget=300000 \
  --dump-dom "file://$PWD/index.html?n=4000#selftest" | grep -o 'data-overflow="[^"]*"'
```

**Run it after any change to generators, `need()/minH()`, CSS sizes, margins or strings.** When it reports a cell, the tag shows
`type/columns/rows/lang/difficulty/op/digits/range/margin` so you can reproduce it (`?tab=<type>&cols=…&rows=…&lang=…`).
Typical fixes: raise `minH`, raise `need()`, shrink a font in the compact CSS class, or lower the maximum margin.

### Visual check / PDF
```bash
google-chrome --headless=new --no-sandbox --disable-gpu --no-pdf-header-footer \
  --virtual-time-budget=5000 --print-to-pdf=/tmp/out.pdf \
  "file://$PWD/index.html?tab=column&op=mul&mdl=x2&diff=medium&seed=3"
pdfinfo /tmp/out.pdf      # page count; A4 = 594.96 x 841.92 pts
pdftoppm -r 60 -png /tmp/out.pdf /tmp/out
```
Check Tamil (`&lang=ta`) as well – it wraps more than English.

---

## 9. Printing and CSS notes

* Page size comes from `@page { size: A4; margin: 0 }`; real margins are the `.page` padding.
* Page breaks: `.pwrap { break-after: page }` (the last one `auto`). `.page` has `overflow: hidden`, so clipped content is *lost*, not pushed to
  the next page – the layout engine and self-test exist to prevent that.
* Fonts: the `.page` font stack starts with `TamilSub` (Tamil-only `unicode-range`) so Tamil always uses the embedded font and Latin text uses the
  system UI font.
* Heights of cells are `height: var(--rh, <fallback>)`; the fallback values are used by fixed layouts (Mixed Test).
* Use `mm`/`pt`, not `px`/`rem`, inside `.page` – the sheet must look the same on every device.
* Dark mode applies to the app UI only (`prefers-color-scheme`); sheets are always black on white.

---

## 10. Assets and release

### Regenerate the Tamil font subset
```bash
python3 -m pip install fonttools brotli
for w in Regular Bold; do
  python3 -m fontTools.subset /usr/share/fonts/truetype/noto/NotoSansTamil-$w.ttf \
    --unicodes=U+0B80-0BFF,U+200C,U+200D --flavor=woff2 --layout-features='*' --output-file=ta-$w.woff2
done
```
Then base64-encode each file into a `@font-face` rule in `fonts.css` (family `TamilSub`, weights 400/700,
`unicode-range: U+0B80-0BFF,U+200C-200D`). Keep `--layout-features='*'` – Tamil needs its shaping tables.

### Icons
`icons/icon.svg` is the source:
```bash
convert -background none -density 384 icons/icon.svg -resize 512x512 icons/icon-512.png
convert icons/icon-512.png -resize 192x192 icons/icon-192.png
```

### Release checklist
1. Run the self-test (§8) – expect `OK`.
2. Eyeball PDFs of the changed types in English and Tamil.
3. Bump `VERSION` in `sw.js` (otherwise installed apps keep the old cached files).
4. If you added files that must work offline, add them to `SHELL` in `sw.js`.
5. Commit and push (GitHub Pages redeploys automatically).

---

## 11. Pitfalls

* **Measure with the right margins.** Anything that calls `availBody()`/`layoutFor()` before `applyMargins()` gets stale numbers
  (`availBody` now applies margins itself – keep that line).
* **Strings in both languages.** A missing Tamil key silently shows English; a missing English key shows `undefined`.
* **`uniq` keys.** Make `k` capture everything that makes two questions "the same"; otherwise duplicates appear or the sheet loops through retries.
* **Singular/plural.** Generators that put a number in a sentence must avoid `1` where a plural noun follows (`itWord` retries until both numbers ≥ 2).
* **Emoji sheets** depend on the user's emoji font; avoid emoji needing variation selectors (e.g. `✏️`).
* **Fixed heights.** Any new cell class that has content taller than `minH` will be clipped – run the self-test and keep fallbacks in `var(--rh, …)`.
* **`localStorage` can throw** (private mode, blocked storage): always go through `save()` / the guarded read.
* **Service worker caching** can make changes look "ignored": hard-reload, or bump `VERSION` and reload twice.

---

## 12. Ideas for future work

* Number-line / ten-frame visuals for picture sheets; money, clock, measurement and fraction sheets.
* A per-page "student name" field and themes for picture sheets.
* Export each page as PNG (add html2canvas as an optional button; PDF via print remains the primary path).
* Regroup `app.js` into ES modules (`strings.js`, `generators.js`, `types.js`, `layout.js`, `ui.js`) if it grows beyond ~1,500 lines –
  the sections in §2 are already divided along those lines.
* Automated headless test in CI (run the self-test and fail on anything but `OK`).
